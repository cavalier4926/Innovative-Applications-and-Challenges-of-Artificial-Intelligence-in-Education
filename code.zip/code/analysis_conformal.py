"""Uncertainty quantification: marginal vs Mondrian (group-conditional) split conformal prediction
and selective prediction, computed from saved calibration/test predictions."""
import json
import os

import numpy as np

import data as dmod
from metrics import conformal_sets, conformal_report

ROOT = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(ROOT, "..", "data", "raw")
RUNS = os.path.join(ROOT, "..", "results", "runs")
OUT = os.path.join(ROOT, "..", "results", "conformal")
os.makedirs(OUT, exist_ok=True)


def flat(Dsplit, P):
    s = Dsplit.m > 0
    g = np.broadcast_to(Dsplit.group[:, None], Dsplit.m.shape)[s]
    return Dsplit.r[s].astype(int), P[s], g


def main():
    res = {}
    cover_curves = {}
    for model in ["GBDT-FE", "SAKT", "AKT-s", "CAFE-KT"]:
        per_seed = []
        for seed in range(5):
            f = os.path.join(RUNS, f"main__{model}__s{seed}.npz")
            if not os.path.exists(f):
                continue
            D, *_ = dmod.build(RAW, seed=seed)
            pr = np.load(f)
            yc, pc, gc = flat(D["calib"], pr["P_calib"])
            yt, pt, gt = flat(D["test"], pr["P_test"])
            row = {}
            for alpha in [0.05, 0.1, 0.2]:
                i0, i1 = conformal_sets(pc, yc, pt, alpha)
                row[f"marginal_{alpha}"] = conformal_report(i0, i1, yt, gt)
                i0, i1 = conformal_sets(pc, yc, pt, alpha, gc, gt)
                row[f"mondrian_{alpha}"] = conformal_report(i0, i1, yt, gt)
            # selective prediction: accuracy when abstaining on the least confident fraction
            conf = np.maximum(pt, 1 - pt)
            order = np.argsort(-conf)
            correct = ((pt >= 0.5) == yt)[order]
            covs = np.linspace(0.1, 1.0, 19)
            row["selective"] = dict(coverage=covs.tolist(),
                                    accuracy=[float(correct[:max(1, int(c * len(correct)))].mean()) for c in covs])
            per_seed.append(row)
        if not per_seed:
            continue
        agg = {}
        for key in per_seed[0]:
            if key == "selective":
                acc = np.array([r[key]["accuracy"] for r in per_seed])
                agg[key] = dict(coverage=per_seed[0][key]["coverage"], accuracy_mean=acc.mean(0).tolist(),
                                accuracy_sd=acc.std(0).tolist())
            else:
                agg[key] = {m: [float(np.mean([r[key][m] for r in per_seed])),
                                float(np.std([r[key][m] for r in per_seed], ddof=1)) if len(per_seed) > 1 else 0.0]
                            for m in per_seed[0][key]}
        res[model] = agg
        print(model, "alpha=0.1 marginal", {k: round(v[0], 4) for k, v in agg["marginal_0.1"].items()})
        print(model, "alpha=0.1 mondrian", {k: round(v[0], 4) for k, v in agg["mondrian_0.1"].items()})
    with open(os.path.join(OUT, "conformal.json"), "w") as f:
        json.dump(res, f, indent=1)


if __name__ == "__main__":
    main()

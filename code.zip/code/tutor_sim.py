"""
Application study: closed-loop adaptive practice in the ground-truth simulator.

New students (never seen in training) practise for T steps.  At every step a policy
chooses the next item; the simulator returns the response, updates the hidden
knowledge state, applies forgetting between attempts/sessions and applies the
disengagement hazard at the end of each session.  Policies:
    Random       : uniformly random item
    Curriculum   : the business-as-usual linear curriculum used to log the training data
    SAKT-ZPD     : item whose SAKT-predicted success is closest to the target (0.7)
    CAFE-KT-ZPD  : same rule with CAFE-KT predictions
    CAFE-KT-ZPD+U: CAFE-KT-ZPD that skips items whose conformal prediction set is {0,1}
                   (uncertain) when a confident alternative exists
    Oracle-ZPD   : same rule with the simulator's true probabilities (upper bound)
All policies see the same students and the same random-number streams (common random numbers).
"""
import json
import os
import pickle
import sys

import numpy as np

import data as dmod
import models
from simulator import EduSimulator
from metrics import conformal_sets
import classic

ROOT = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(ROOT, "..", "results", "runs")
OUT = os.path.join(ROOT, "..", "results", "tutoring")
TARGET = 0.7
TAU_M, TAU_R, MAX_ATT = 0.75, 0.55, 8      # mastery-learning thresholds (MLR policies)


def load_model(arch, run_id, Q, K):
    m = models.make_model(arch, Q, K, seed=0)
    with open(os.path.join(RUNS, run_id + ".pkl"), "rb") as f:
        m.load_state_dict(pickle.load(f))
    return m


class GBDTPolicyModel:
    """Wraps the fitted GBDT-FE baseline so it can score every candidate item from a history."""

    def __init__(self, gb, K):
        self.gb, self.K = gb, K

    def predict_next(self, hist, cand_q, cand_k, t_now):
        B, s = hist["k"].shape
        Q = len(cand_q)
        rows = []
        for b in range(B):
            k_h, r_h, t_h = hist["k"][b], hist["r"][b], hist["t"][b]
            nk = np.bincount(k_h, minlength=self.K).astype(float)
            ck = np.bincount(k_h, weights=r_h, minlength=self.K)
            last_t = np.full(self.K, np.nan)
            last_r = np.full(self.K, -1.0)
            for j in range(s):
                last_t[k_h[j]] = t_h[j]
                last_r[k_h[j]] = r_h[j]
            n_all, c_all = s, float(r_h.sum())
            rec5 = r_h[-5:].mean() if s else 0.5
            dt_last = np.log1p(t_now[b] - t_h[-1]) if s else -1.0
            kk = cand_k
            dtk = np.where(np.isnan(last_t[kk]), -1.0, np.log1p(np.maximum(t_now[b] - np.nan_to_num(last_t[kk]), 0)))
            F = np.column_stack([np.zeros(Q), np.full(Q, s), cand_q, kk, np.full(Q, n_all),
                                 np.full(Q, (c_all + 1) / (n_all + 2)), nk[kk], (ck[kk] + 1) / (nk[kk] + 2),
                                 ck[kk], nk[kk] - ck[kk], last_r[kk], np.full(Q, rec5), np.full(Q, dt_last), dtk,
                                 np.full(Q, s)])
            rows.append(F)
        F = np.vstack(rows)
        p = self.gb.m.predict_proba(self.gb._X(F))[:, 1]
        return p.reshape(B, Q)


def simulate(policy, sim, n_students, T, seed, model=None, qhat=None, chunk=100):
    rng0 = np.random.default_rng(seed)
    studs = [sim.new_student(np.random.default_rng(seed * 100000 + i)) for i in range(n_students)]
    rngs = [np.random.default_rng(seed * 7919 + i) for i in range(n_students)]
    pre = np.array([sim.mastery_score(s) for s in studs])
    H = {k: np.zeros((n_students, T), np.int64) for k in ["q", "k", "r"]}
    H["t"] = np.zeros((n_students, T), np.float32)
    active = np.ones(n_students, bool)
    dropped = np.zeros(n_students, bool)
    n_done = np.zeros(n_students, int)
    sess_left = np.array([int(r.poisson(8) + 3) for r in rngs])
    last_gap = np.zeros(n_students)
    ptr = np.zeros(n_students, int)
    streak = np.zeros(n_students, int)
    att = np.zeros(n_students, int)
    recent = [[] for _ in range(n_students)]
    cand_q = np.arange(sim.Q)
    cand_k = sim.item_concept
    for step in range(T):
        idx = np.where(active)[0]
        if len(idx) == 0:
            break
        # ---- choose items
        choice = np.zeros(n_students, int)
        Pm = {}
        if policy.endswith("ZPD") or policy.endswith("ZPD+U") or policy.endswith("MLR"):
          if not policy.startswith("Oracle"):
              for c0 in range(0, len(idx), chunk):
                  ii = idx[c0:c0 + chunk]
                  hist = {k: H[k][ii, :step] for k in ["q", "k", "r", "t"]}
                  tnow = np.array([studs[i]["t"] for i in ii], np.float32)
                  P = model.predict_next(hist, cand_q, cand_k, tnow)
                  for row, i in enumerate(ii):
                      Pm[i] = P[row]
                  score = np.abs(P - TARGET)
                  # avoid immediate repetition of the last 10 items
                  for row, i in enumerate(ii):
                      score[row, H["q"][i, max(0, step - 10):step]] += 10
                  if policy == "CAFE-KT-ZPD+U":
                      uncertain = ((1 - P) <= qhat) & (P <= qhat)
                      score = score + 0.5 * uncertain
                  choice[ii] = score.argmin(1)
        for i in idx:
            st, r = studs[i], rngs[i]
            if policy == "Random":
                q = int(r.integers(sim.Q))
            elif policy == "Curriculum":
                if ptr[i] >= sim.K:
                    ptr[i] = sim.K - 1
                if ptr[i] > 0 and r.random() < 0.25:
                    k = int(r.integers(0, ptr[i]))
                    rev = True
                else:
                    k, rev = ptr[i], False
                q = int(r.choice(sim.items_of[k]))
            elif policy == "Oracle-ZPD":
                P = sim.p_correct_all(st)
                sc = np.abs(P - TARGET)
                sc[H["q"][i, max(0, step - 10):step]] += 10
                q = int(sc.argmin())
            elif policy.endswith("MLR"):
                # mastery learning with forgetting-aware review, driven by the model's predictions
                P = sim.p_correct_all(st) if policy.startswith("Oracle") else Pm[i]
                pk = np.array([P[sim.items_of[c]].mean() for c in range(sim.K)])
                if ptr[i] < sim.K - 1 and (pk[ptr[i]] >= TAU_M or att[i] >= MAX_ATT):
                    ptr[i] += 1
                    att[i] = 0
                kk = ptr[i]
                rev = False
                if ptr[i] > 0:
                    j = int(np.argmin(pk[:ptr[i]]))
                    if pk[j] < TAU_R:
                        kk, rev = j, True
                items = sim.items_of[kk]
                sc = np.abs(P[items] - TARGET)
                sc[np.isin(items, H["q"][i, max(0, step - 10):step])] += 10
                q = int(items[int(sc.argmin())])
                if not rev:
                    att[i] += 1
            else:
                q = int(choice[i])
            k = int(sim.item_concept[q])
            p = sim.p_correct(st, q)
            y = int(r.random() < p)
            H["q"][i, step], H["k"][i, step], H["r"][i, step], H["t"][i, step] = q, k, y, st["t"]
            sim.learn(st, q, y)
            recent[i].append(y)
            n_done[i] += 1
            if policy == "Curriculum" and not rev:
                att[i] += 1
                streak[i] = streak[i] + 1 if y else 0
                if streak[i] >= 3 or att[i] >= 8:
                    ptr[i] += 1
                    streak[i], att[i] = 0, 0
            sess_left[i] -= 1
            if sess_left[i] > 0:
                dt = sim.within_gap_hours(r)
                sim.forget(st, dt)
                st["t"] += dt
            else:
                err = 1 - np.mean(recent[i][-10:])
                h = sim.dropout_hazard(err, last_gap[i])
                if r.random() < h:
                    active[i] = False
                    dropped[i] = True
                    continue
                gap = sim.session_gap_hours(r, st["group"])
                last_gap[i] = gap / 24.0
                sim.forget(st, gap)
                st["t"] += gap
                sess_left[i] = int(r.poisson(8) + 3)
    # post-test one day after the last activity (forgetting applies)
    for st in studs:
        sim.forget(st, 24.0)
    post = np.array([sim.mastery_score(s) for s in studs])
    grp = np.array([s["group"] for s in studs])
    corr = np.array([H["r"][i, :n_done[i]].mean() if n_done[i] else np.nan for i in range(n_students)])
    res = dict(policy=policy, n=n_students, T=T,
               pre=float(pre.mean()), post=float(post.mean()), gain=float((post - pre).mean()),
               gain_sd=float((post - pre).std()), dropout=float(dropped.mean()),
               practice_correct=float(np.nanmean(corr)), steps=float(n_done.mean()))
    for g in [0, 1]:
        s = grp == g
        res[f"gain_g{g}"] = float((post - pre)[s].mean())
        res[f"dropout_g{g}"] = float(dropped[s].mean())
    res["per_student_gain"] = (post - pre).tolist()
    res["group"] = grp.tolist()
    return res


def main():
    os.makedirs(OUT, exist_ok=True)
    n, T = int(sys.argv[1]) if len(sys.argv) > 1 else 300, int(sys.argv[2]) if len(sys.argv) > 2 else 60
    sim = EduSimulator(seed=2026)
    Q, K = sim.Q, sim.K
    sakt = load_model("SAKT", "main__SAKT__s0", Q, K)
    akt = load_model("AKT-s", "main__AKT-s__s0", Q, K)
    cafe = load_model("CAFE-KT", "main__CAFE-KT__s0", Q, K)
    # conformal threshold (alpha = 0.1) from the calibration split of CAFE-KT seed 0
    D, *_ = dmod.build(os.path.join(ROOT, "..", "data", "raw"), seed=0)
    gbdt = GBDTPolicyModel(classic.GBDTKT(Q, seed=0).fit(D["train"]), K)
    pr = np.load(os.path.join(RUNS, "main__CAFE-KT__s0.npz"))
    s = D["calib"].m > 0
    y, p = D["calib"].r[s], pr["P_calib"][s]
    sc = np.where(y == 1, 1 - p, p)
    nq = len(sc)
    qhat = float(np.quantile(sc, min(1, np.ceil((nq + 1) * 0.9) / nq), method="higher"))
    out = {}
    policies = [("Random", None), ("Curriculum", None),
                ("GBDT-FE-ZPD", gbdt), ("SAKT-ZPD", sakt), ("AKT-s-ZPD", akt), ("CAFE-KT-ZPD", cafe),
                ("CAFE-KT-ZPD+U", cafe), ("Oracle-ZPD", None),
                ("GBDT-FE-MLR", gbdt), ("SAKT-MLR", sakt), ("AKT-s-MLR", akt), ("CAFE-KT-MLR", cafe),
                ("Oracle-MLR", None)]
    out = {}
    for pol, mdl in policies:
        res = []
        for seed in [11, 12]:
            sim_s = EduSimulator(seed=2026)       # identical world for every policy
            r = simulate(pol, sim_s, n, T, seed, model=mdl, qhat=qhat)
            res.append(r)
            print(pol, seed, {k: round(v, 4) for k, v in r.items() if isinstance(v, float)}, flush=True)
        out[pol] = res
        with open(os.path.join(OUT, "tutoring_results.json"), "w") as f:
            json.dump(dict(qhat=qhat, target=TARGET, tau_m=TAU_M, tau_r=TAU_R, results=out), f)


if __name__ == "__main__":
    main()

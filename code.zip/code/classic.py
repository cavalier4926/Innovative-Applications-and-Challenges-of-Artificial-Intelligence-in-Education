"""Classical baselines: BKT (EM), PFA (logistic regression), GBDT with engineered features,
and feature-based early-warning models."""
import numpy as np
import scipy.sparse as sp
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression


# ======================================================================= BKT
class BKT:
    """Per-concept 4-parameter Bayesian Knowledge Tracing fitted with EM (Baum-Welch)."""

    def __init__(self, K, n_iter=30):
        self.K, self.n_iter = K, n_iter
        self.params = np.tile([0.3, 0.15, 0.2, 0.1], (K, 1))  # L0, T, G, S

    @staticmethod
    def _seqs(D, k):
        out = []
        for i in range(D.n):
            s = (D.m[i] > 0) & (D.k[i] == k)
            if s.any():
                out.append(D.r[i][s])
        return out

    def fit(self, D):
        for k in range(self.K):
            seqs = self._seqs(D, k)
            if not seqs:
                continue
            M = max(len(s) for s in seqs)
            N = len(seqs)
            O = np.zeros((N, M))
            Mk = np.zeros((N, M))
            for i, s in enumerate(seqs):
                O[i, :len(s)] = s
                Mk[i, :len(s)] = 1
            L0, T, G, S = self.params[k]
            for _ in range(self.n_iter):
                e1 = np.where(O == 1, 1 - S, S)          # P(obs | learned)
                e0 = np.where(O == 1, G, 1 - G)          # P(obs | unlearned)
                e1 = np.where(Mk > 0, e1, 1.0)
                e0 = np.where(Mk > 0, e0, 1.0)
                a = np.zeros((N, M, 2))
                c = np.zeros((N, M))
                a0 = np.stack([(1 - L0) * e0[:, 0], L0 * e1[:, 0]], -1)
                c[:, 0] = a0.sum(-1)
                a[:, 0] = a0 / c[:, :1]
                for t in range(1, M):
                    pu = a[:, t - 1, 0] * (1 - T)
                    pl = a[:, t - 1, 0] * T + a[:, t - 1, 1]
                    at = np.stack([pu * e0[:, t], pl * e1[:, t]], -1)
                    c[:, t] = at.sum(-1)
                    a[:, t] = at / c[:, t:t + 1]
                b = np.ones((N, M, 2))
                for t in range(M - 2, -1, -1):
                    nb0 = e0[:, t + 1] * b[:, t + 1, 0]
                    nb1 = e1[:, t + 1] * b[:, t + 1, 1]
                    b[:, t, 0] = ((1 - T) * nb0 + T * nb1) / c[:, t + 1]
                    b[:, t, 1] = nb1 / c[:, t + 1]
                gam = a * b
                gam /= gam.sum(-1, keepdims=True)
                xi = np.zeros((N, M))
                for t in range(M - 1):
                    xi[:, t] = a[:, t, 0] * T * e1[:, t + 1] * b[:, t + 1, 1] / c[:, t + 1]
                valid_tr = Mk[:, 1:] * Mk[:, :-1]
                L0 = np.clip(gam[:, 0, 1].mean(), 1e-3, 0.999)
                T = np.clip((xi[:, :-1] * valid_tr).sum() / ((gam[:, :-1, 0] * valid_tr).sum() + 1e-9), 1e-3, 0.999)
                G = np.clip((gam[:, :, 0] * (O == 1) * Mk).sum() / ((gam[:, :, 0] * Mk).sum() + 1e-9), 1e-3, 0.4)
                S = np.clip((gam[:, :, 1] * (O == 0) * Mk).sum() / ((gam[:, :, 1] * Mk).sum() + 1e-9), 1e-3, 0.4)
            self.params[k] = [L0, T, G, S]
        return self

    def predict(self, D):
        P = np.zeros(D.m.shape, np.float32)
        for i in range(D.n):
            pL = self.params[:, 0].copy()
            for t in range(int(D.length[i])):
                k = D.k[i, t]
                L0, T, G, S = self.params[k]
                pc = pL[k] * (1 - S) + (1 - pL[k]) * G
                P[i, t] = pc
                if D.r[i, t] == 1:
                    post = pL[k] * (1 - S) / pc
                else:
                    post = pL[k] * S / (1 - pc)
                pL[k] = post + (1 - post) * T
        return P


# ======================================================================= feature extraction
def interaction_features(D, item_stats=None):
    """Causal per-interaction features (only information before the current attempt)."""
    rows = []
    K = int(D.k.max()) + 1
    for i in range(D.n):
        Lb = int(D.length[i])
        nk = np.zeros(K)
        ck = np.zeros(K)
        last_t_k = np.full(K, np.nan)
        last_r_k = np.full(K, -1.0)
        hist = []
        for t in range(Lb):
            k, q, tm = D.k[i, t], D.q[i, t], D.t[i, t]
            n_all = len(hist)
            c_all = sum(hist)
            dt_last = np.log1p(tm - D.t[i, t - 1]) if t > 0 else -1.0
            dt_k = np.log1p(tm - last_t_k[k]) if not np.isnan(last_t_k[k]) else -1.0
            rec5 = np.mean(hist[-5:]) if hist else 0.5
            rows.append((i, t, q, k, n_all, (c_all + 1) / (n_all + 2), nk[k], (ck[k] + 1) / (nk[k] + 2),
                         ck[k], nk[k] - ck[k], last_r_k[k], rec5, dt_last, dt_k, t))
            r = D.r[i, t]
            hist.append(r)
            nk[k] += 1
            ck[k] += r
            last_t_k[k] = tm
            last_r_k[k] = r
    F = np.array(rows, dtype=np.float64)
    return F


def pfa_design(F, Q, K):
    n = len(F)
    q = F[:, 2].astype(int)
    k = F[:, 3].astype(int)
    rows = np.arange(n)
    X_item = sp.csr_matrix((np.ones(n), (rows, q)), shape=(n, Q))
    X_s = sp.csr_matrix((F[:, 8], (rows, k)), shape=(n, K))
    X_f = sp.csr_matrix((F[:, 9], (rows, k)), shape=(n, K))
    return sp.hstack([X_item, X_s, X_f]).tocsr()


def labels_of(D, F):
    return D.r[F[:, 0].astype(int), F[:, 1].astype(int)].astype(int)


class PFA:
    def __init__(self, Q, K):
        self.Q, self.K = Q, K
        self.lr = LogisticRegression(C=1.0, max_iter=1000)

    def fit(self, D):
        F = interaction_features(D)
        self.lr.fit(pfa_design(F, self.Q, self.K), labels_of(D, F))
        return self

    def predict(self, D):
        F = interaction_features(D)
        P = np.zeros(D.m.shape, np.float32)
        P[F[:, 0].astype(int), F[:, 1].astype(int)] = self.lr.predict_proba(pfa_design(F, self.Q, self.K))[:, 1]
        return P


class GBDTKT:
    def __init__(self, Q, seed=0):
        self.Q = Q
        self.m = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.08, max_leaf_nodes=31,
                                                early_stopping=True, validation_fraction=0.1,
                                                random_state=seed)

    def _X(self, F):
        q = F[:, 2].astype(int)
        return np.column_stack([self.item_rate[q], self.item_n[q], F[:, 3], F[:, 4:]])

    def fit(self, D):
        F = interaction_features(D)
        y = labels_of(D, F)
        q = F[:, 2].astype(int)
        cnt = np.bincount(q, minlength=self.Q)
        cor = np.bincount(q, weights=y, minlength=self.Q)
        prior = y.mean()
        self.item_rate = (cor + 10 * prior) / (cnt + 10)
        self.item_n = np.log1p(cnt)
        self.m.fit(self._X(F), y)
        return self

    def predict(self, D):
        F = interaction_features(D)
        P = np.zeros(D.m.shape, np.float32)
        P[F[:, 0].astype(int), F[:, 1].astype(int)] = self.m.predict_proba(self._X(F))[:, 1]
        return P


# ======================================================================= early warning (features)
def ew_features(D, t):
    """Features from the first t interactions of every student with length > t."""
    idx = np.where(D.length > t)[0]
    X = []
    for i in idx:
        r = D.r[i, :t]
        tm = D.t[i, :t]
        k = D.k[i, :t]
        gaps = np.diff(tm)
        sess_gaps = gaps[gaps > 1.0]
        X.append([r.mean(), r[-10:].mean(), r[-5:].mean(), len(sess_gaps),
                  np.log1p(sess_gaps.mean()) if len(sess_gaps) else 0.0,
                  np.log1p(sess_gaps[-1]) if len(sess_gaps) else 0.0,
                  np.log1p(tm[-1] - tm[0]), k.max(), len(np.unique(k))])
    return idx, np.array(X)


class EWBaseline:
    def __init__(self, kind, seed=0):
        if kind == "LR":
            self.m = LogisticRegression(max_iter=2000, C=1.0)
        else:
            self.m = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, random_state=seed)
        self.kind = kind

    def fit(self, D, t):
        idx, X = ew_features(D, t)
        self.mu, self.sd = X.mean(0), X.std(0) + 1e-6
        self.m.fit((X - self.mu) / self.sd, D.dropout[idx].astype(int))
        return self

    def predict(self, D, t):
        idx, X = ew_features(D, t)
        return idx, self.m.predict_proba((X - self.mu) / self.sd)[:, 1]

"""
Interpretability and diagnostic analyses against simulator ground truth.

 (1) Counterfactual forgetting curves: how much does each model lower P(correct) when the
     time since the last practice grows (1 h -> 7 days)?  Compared with the exact answer
     obtained by replaying each student's log through the simulator.
 (2) Counterfactual influence graph: flip one past response and measure the change of the
     predicted success on every concept; after removing the general-ability effect the
     resulting matrix is scored against the true prerequisite DAG (AUROC).
 (3) Error analysis by time gap since last same-concept practice and by sequence position
     (cold start), pooled over seeds, from saved predictions.
 (4) Attention example for one student.
Outputs: results/interpret/*.json / *.npz
"""
import json
import os
import pickle

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, pearsonr
from sklearn.metrics import roc_auc_score

import data as dmod
import models
from simulator import EduSimulator

ROOT = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(ROOT, "..", "data", "raw")
RUNS = os.path.join(ROOT, "..", "results", "runs")
OUT = os.path.join(ROOT, "..", "results", "interpret")
os.makedirs(OUT, exist_ok=True)
HS = 40            # history length used for probes
N_PROBE = 300


def load(arch, run_id, Q, K):
    m = models.make_model(arch, Q, K, seed=0)
    with open(os.path.join(RUNS, run_id + ".pkl"), "rb") as f:
        m.load_state_dict(pickle.load(f))
    return m


def replay(sim, srow, q, r, t, t_now):
    st = sim.new_student(np.random.default_rng(0), group=int(srow.group), school=int(srow.school_id))
    st.update(theta=srow.theta, eta=srow.eta, phi=srow.phi, slip=srow.slip)
    st["z"] = np.zeros(sim.K)
    st["npr"] = np.zeros(sim.K)
    for j in range(len(q)):
        if j > 0:
            sim.forget(st, t[j] - t[j - 1])
        sim.learn(st, int(q[j]), int(r[j]))
    sim.forget(st, t_now - t[-1])
    return st


def main():
    D, Q, K, inter, stud, sp = dmod.build(RAW, seed=0)
    sim = EduSimulator(seed=2026)
    srows = stud.set_index("student_id")
    A = np.zeros((K, K))
    e = pd.read_csv(os.path.join(RAW, "prerequisite_edges.csv"))
    A[e.child_concept, e.parent_concept] = 1
    te = D["test"]
    sel = np.where(te.length > HS)[0][:N_PROBE]
    hist = {k: getattr(te, k)[sel, :HS] for k in ["q", "k", "r", "t"]}
    t_last = hist["t"][:, -1]
    mods = {"CAFE-KT": load("CAFE-KT", "main__CAFE-KT__s0", Q, K),
            "AKT-s": load("AKT-s", "main__AKT-s__s0", Q, K),
            "SAKT": load("SAKT", "main__SAKT__s0", Q, K),
            "DKT": load("DKT", "main__DKT__s0", Q, K)}
    for v in ["CAFE-KT w/o forgetting kernel", "CAFE-KT w/o query features"]:
        rid = "ablation__" + v.replace(" ", "_").replace("/", "") + "__s0"
        if os.path.exists(os.path.join(RUNS, rid + ".pkl")):
            mods[v] = load(v, rid, Q, K)
    res = {}
    # ---------------------------------------------------------------- (1) forgetting
    deltas = [1.0, 6.0, 24.0, 72.0, 168.0]
    cand_q = np.arange(Q)
    cand_k = sim.item_concept
    practiced = np.zeros((len(sel), K), bool)
    for b in range(len(sel)):
        practiced[b, np.unique(hist["k"][b])] = True
    curves = {}
    for name, m in mods.items():
        P = []
        for dlt in deltas:
            P.append(m.predict_next(hist, cand_q, cand_k, (t_last + dlt).astype(np.float32)))
        curves[name] = np.stack(P)               # (n_delta, B, Q)
    truth = np.zeros((len(deltas), len(sel), Q))
    for b, i in enumerate(sel):
        srow = srows.loc[te.ids[i]]
        for di, dlt in enumerate(deltas):
            st = replay(sim, srow, hist["q"][b], hist["r"][b], hist["t"][b], t_last[b] + dlt)
            truth[di, b] = sim.p_correct_all(st)
    curves["Ground truth"] = truth

    def concept_curve(Pc):
        # mean over practiced (student, concept) pairs of the mean item probability of the concept
        per = np.stack([Pc[:, :, sim.items_of[k]].mean(-1) for k in range(K)], -1)   # (nd,B,K)
        return per

    fc = {}
    true_per = concept_curve(truth)
    true_drop = (true_per[0] - true_per[-1])[practiced]
    valid_k = practiced.sum(0) >= 10
    true_drop_k = np.array([(true_per[0, :, k] - true_per[-1, :, k])[practiced[:, k]].mean() if valid_k[k] else np.nan
                            for k in range(K)])
    for name, Pc in curves.items():
        per = concept_curve(Pc)
        drop = (per[0] - per[-1])[practiced]
        drop_k = np.array([(per[0, :, k] - per[-1, :, k])[practiced[:, k]].mean() if valid_k[k] else np.nan
                           for k in range(K)])
        curve = [float(per[di][practiced].mean()) for di in range(len(deltas))]
        rec = dict(curve=curve, mean_drop=float(drop.mean()))
        if name != "Ground truth" and drop.std() > 1e-9:
            rec["pearson_pairs"] = float(pearsonr(drop, true_drop)[0])
            rec["spearman_concepts"] = float(spearmanr(drop_k[valid_k], true_drop_k[valid_k])[0])
            rec["n_concepts"] = int(valid_k.sum())
        else:
            rec["pearson_pairs"] = None if name != "Ground truth" else 1.0
            rec["spearman_concepts"] = None if name != "Ground truth" else 1.0
        rec["drop_by_concept"] = [None if np.isnan(x) else float(x) for x in drop_k]
        rec["mean_drop_true_matched"] = float(true_drop.mean())
        fc[name] = rec
    lam = pd.read_csv(os.path.join(RAW, "concepts.csv")).forgetting_rate_per_day.values
    fc["true_lambda"] = lam.tolist()
    fc["deltas_h"] = deltas
    res["forgetting"] = fc
    print("forgetting:", {k: (round(v["mean_drop"], 4), v["pearson_pairs"], v["spearman_concepts"])
                          for k, v in fc.items() if isinstance(v, dict)})
    # ---------------------------------------------------------------- (2) influence graph
    rep_items = np.array([sim.items_of[k][np.argsort(sim.b[sim.items_of[k]])[len(sim.items_of[k]) // 2]]
                          for k in range(K)])
    t_now = te.t[sel, HS].astype(np.float32)

    def influence(predict):
        I = np.zeros((K, K))
        C = np.zeros((K, K))
        for p in range(HS):
            h1 = {k: v.copy() for k, v in hist.items()}
            h0 = {k: v.copy() for k, v in hist.items()}
            h1["r"][:, p] = 1
            h0["r"][:, p] = 0
            d = predict(h1) - predict(h0)                     # (B, K)
            kj = hist["k"][:, p]
            for b in range(len(sel)):
                I[:, kj[b]] += d[b]
                C[:, kj[b]] += 1
        I = I / np.maximum(C, 1)
        return I, C

    def normalise(I):
        J = I.copy()
        np.fill_diagonal(J, np.nan)
        J = J - np.nanmean(J, axis=1, keepdims=True)
        return J

    ii, jj = np.meshgrid(np.arange(K), np.arange(K), indexing="ij")
    win = (ii - jj > 0) & (ii - jj <= 6)
    low = (ii - jj > 0)
    graph = {}
    for name, m in mods.items():
        I, C = influence(lambda h: m.predict_next(h, rep_items, np.arange(K), t_now))
        J = normalise(I)
        ok_w = win & (C > 0)
        ok_l = low & (C > 0)
        graph[name] = dict(AUROC_window=float(roc_auc_score(A[ok_w], J[ok_w])),
                           AUROC_lower=float(roc_auc_score(A[ok_l], J[ok_l])),
                           I=I.tolist())
    # ground-truth interventional influence via replay
    def true_predict(h):
        out = np.zeros((len(sel), K))
        for b, i in enumerate(sel):
            st = replay(sim, srows.loc[te.ids[i]], h["q"][b], h["r"][b], h["t"][b], t_now[b])
            out[b] = sim.p_correct_all(st)[rep_items]
        return out
    I, C = influence(true_predict)
    J = normalise(I)
    ok_w = win & (C > 0)
    ok_l = low & (C > 0)
    graph["Simulator (interventional)"] = dict(AUROC_window=float(roc_auc_score(A[ok_w], J[ok_w])),
                                               AUROC_lower=float(roc_auc_score(A[ok_l], J[ok_l])),
                                               I=I.tolist())
    # statistical baseline: outcome lift on concept i after a correct vs wrong last attempt on j
    tr = D["train"]
    S1 = np.zeros((K, K)); N1 = np.zeros((K, K)); S0 = np.zeros((K, K)); N0 = np.zeros((K, K))
    for i in range(tr.n):
        L = int(tr.length[i])
        last = np.full(K, -1)
        for t in range(L):
            k = tr.k[i, t]
            seen = last >= 0
            S1[k, seen & (last == 1)] += tr.r[i, t]
            N1[k, seen & (last == 1)] += 1
            S0[k, seen & (last == 0)] += tr.r[i, t]
            N0[k, seen & (last == 0)] += 1
            last[k] = tr.r[i, t]
    lift = S1 / np.maximum(N1, 1) - S0 / np.maximum(N0, 1)
    J = normalise(lift)
    ok = win & (N1 > 20) & (N0 > 20)
    okl = low & (N1 > 20) & (N0 > 20)
    graph["Conditional-lift statistic"] = dict(AUROC_window=float(roc_auc_score(A[ok], J[ok])),
                                               AUROC_lower=float(roc_auc_score(A[okl], J[okl])), I=lift.tolist())
    # learned attention bias G of CAFE-KT
    rec = json.load(open(os.path.join(RUNS, "main__CAFE-KT__s0.json")))
    G = np.array(rec["G"])
    G2 = normalise(G)
    graph["CAFE-KT attention bias G"] = dict(AUROC_window=float(roc_auc_score(A[win], G2[win])),
                                             AUROC_lower=float(roc_auc_score(A[low], G2[low])), I=G.tolist())
    graph["A_true"] = A.tolist()
    res["influence"] = graph
    print("influence:", {k: (round(v["AUROC_window"], 3), round(v["AUROC_lower"], 3))
                         for k, v in graph.items() if isinstance(v, dict)})
    # ---------------------------------------------------------------- (3) buckets (pooled over seeds)
    bucket = {}
    dtk = te.f[:, :, 3] * 8.0          # log1p(hours since last same-concept attempt); first encounter -> 8
    first = te.f[:, :, 4] == 0
    hrs = np.expm1(dtk)
    gb = np.select([first, hrs < 1, hrs < 24, hrs < 72], ["first encounter", "<1 h", "1-24 h", "1-3 d"], "> 3 d")
    pos = np.broadcast_to(np.arange(te.m.shape[1])[None, :], te.m.shape)
    pb = np.select([pos < 5, pos < 20, pos < 50], ["1-5", "6-20", "21-50"], "51-120")
    mask = te.m > 0
    for name in ["GBDT-FE", "DKT", "SAKT", "AKT-s", "CAFE-KT"]:
        rows = {}
        for seed in range(5):
            f = os.path.join(RUNS, f"main__{name}__s{seed}.npz")
            if not os.path.exists(f):
                continue
            Dm, *_ = dmod.build(RAW, seed=seed) if seed else (D,)
            tes = Dm["test"]
            P = np.load(f)["P_test"]
            dk = tes.f[:, :, 3] * 8.0
            fi = tes.f[:, :, 4] == 0
            h_ = np.expm1(dk)
            gbs = np.select([fi, h_ < 1, h_ < 24, h_ < 72], ["first encounter", "<1 h", "1-24 h", "1-3 d"], "> 3 d")
            ps = np.broadcast_to(np.arange(tes.m.shape[1])[None, :], tes.m.shape)
            pbs = np.select([ps < 5, ps < 20, ps < 50], ["1-5", "6-20", "21-50"], "51-120")
            ms_ = tes.m > 0
            for lab_arr, kind in [(gbs, "gap"), (pbs, "pos")]:
                for lab in np.unique(lab_arr[ms_]):
                    s_ = ms_ & (lab_arr == lab)
                    rows.setdefault(kind, {}).setdefault(lab, []).append(
                        float(roc_auc_score(tes.r[s_], P[s_])))
            if seed == 0:
                rows["n_gap"] = {lab: int((ms_ & (gbs == lab)).sum()) for lab in np.unique(gbs[ms_])}
        bucket[name] = rows
    res["buckets"] = bucket
    # ---------------------------------------------------------------- (4) attention example
    i0 = int(np.where(te.length >= 60)[0][3])
    b = {k: getattr(te, k)[i0:i0 + 1, :60] for k in ["q", "k", "r", "t", "m", "f"]}
    att = {}
    for name in ["CAFE-KT", "SAKT"]:
        m = mods[name]
        m.forward(b, training=False)
        att[name] = m.ret.att.last_attn[0].mean(0).tolist()
    res["attention_example"] = dict(student=int(te.ids[i0]), k=b["k"][0].tolist(), r=b["r"][0].tolist(),
                                    t=b["t"][0].tolist(), attn=att)
    with open(os.path.join(OUT, "interpret.json"), "w") as f:
        json.dump(res, f)
    with open(os.path.join(OUT, "forgetting_curves.pkl"), "wb") as f:
        pickle.dump({k: np.stack([curves[k][di][:, :][practiced[:, sim.item_concept]].mean()
                                  for di in range(len(deltas))]) for k in curves}, f)


if __name__ == "__main__":
    main()

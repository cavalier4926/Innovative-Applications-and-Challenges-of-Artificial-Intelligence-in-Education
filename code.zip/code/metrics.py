"""Evaluation metrics: discrimination, calibration, group fairness, conformal prediction."""
import numpy as np
from sklearn.metrics import roc_auc_score, f1_score, average_precision_score


def ece(y, p, n_bins=15):
    bins = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(p, bins) - 1, 0, n_bins - 1)
    e = 0.0
    for b in range(n_bins):
        s = idx == b
        if s.any():
            e += s.mean() * abs(y[s].mean() - p[s].mean())
    return float(e)


def kt_metrics(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return dict(
        AUC=float(roc_auc_score(y, p)),
        ACC=float(((p >= 0.5) == y).mean()),
        RMSE=float(np.sqrt(((p - y) ** 2).mean())),
        NLL=float(-(y * np.log(p) + (1 - y) * np.log(1 - p)).mean()),
        ECE=float(ece(y, p)),
    )


def group_metrics(y, p, g):
    out = {}
    for gg in [0, 1]:
        s = g == gg
        out[gg] = kt_metrics(y[s], p[s])
        out[gg]["CITL"] = float(p[s].mean() - y[s].mean())   # calibration-in-the-large
    out["AUC_gap"] = out[0]["AUC"] - out[1]["AUC"]
    out["ECE_gap"] = out[1]["ECE"] - out[0]["ECE"]
    out["CITL_gap"] = abs(out[1]["CITL"]) - abs(out[0]["CITL"])
    return out


def abroca(y, p, g, n=1000):
    """Absolute Between-ROC Area (Gardner et al., 2019) between group 0 and group 1."""
    from sklearn.metrics import roc_curve
    grid = np.linspace(0, 1, n)
    tprs = []
    for gg in [0, 1]:
        s = g == gg
        fpr, tpr, _ = roc_curve(y[s], p[s])
        tprs.append(np.interp(grid, fpr, tpr))
    return float(np.trapezoid(np.abs(tprs[0] - tprs[1]), grid))


def ew_metrics(y, p, g=None, thr=None):
    """early-warning metrics; threshold chosen on validation set if given."""
    if thr is None:
        thr = 0.5
    yhat = (p >= thr).astype(int)
    out = dict(AUC=float(roc_auc_score(y, p)), AP=float(average_precision_score(y, p)),
               F1=float(f1_score(y, yhat)), thr=float(thr))
    if g is not None:
        for gg in [0, 1]:
            s = (g == gg)
            pos = s & (y == 1)
            out[f"FNR_g{gg}"] = float((yhat[pos] == 0).mean()) if pos.any() else np.nan
            out[f"AUC_g{gg}"] = float(roc_auc_score(y[s], p[s]))
        out["FNR_gap"] = out["FNR_g1"] - out["FNR_g0"]
    return out


def best_f1_threshold(y, p):
    ts = np.linspace(0.05, 0.95, 91)
    f = [f1_score(y, (p >= t).astype(int)) for t in ts]
    return float(ts[int(np.argmax(f))])


# ------------------------------------------------------------ conformal prediction
def conformal_sets(p_cal, y_cal, p_test, alpha, g_cal=None, g_test=None):
    """Split conformal for binary labels with score s = 1 - p(true label).
    If groups are given -> Mondrian (group-conditional) conformal."""
    def qhat(scores):
        n = len(scores)
        lev = min(1.0, np.ceil((n + 1) * (1 - alpha)) / n)
        return np.quantile(scores, lev, method="higher")
    s_cal = np.where(y_cal == 1, 1 - p_cal, p_cal)
    if g_cal is None:
        q = np.full(len(p_test), qhat(s_cal))
    else:
        q = np.zeros(len(p_test))
        for gg in np.unique(g_cal):
            q[g_test == gg] = qhat(s_cal[g_cal == gg])
    inc1 = (1 - p_test) <= q
    inc0 = p_test <= q
    return inc0, inc1


def conformal_report(inc0, inc1, y, g):
    cover = np.where(y == 1, inc1, inc0)
    size = inc0.astype(int) + inc1.astype(int)
    out = dict(coverage=float(cover.mean()), avg_size=float(size.mean()),
               singleton=float((size == 1).mean()), empty=float((size == 0).mean()))
    for gg in [0, 1]:
        s = g == gg
        out[f"coverage_g{gg}"] = float(cover[s].mean())
        out[f"singleton_g{gg}"] = float((size[s] == 1).mean())
    out["coverage_gap"] = abs(out["coverage_g0"] - out["coverage_g1"])
    return out

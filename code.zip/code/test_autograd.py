"""Finite-difference gradient checks for every autograd operator (run: python test_autograd.py)."""
import numpy as np
import autograd as ag

ag.DTYPE = np.float64
rng = np.random.default_rng(0)


def check(name, f, shapes, eps=1e-6, tol=1e-5, positive=False):
    ps = []
    for s in shapes:
        d = rng.normal(size=s)
        if positive:
            d = np.abs(d) + 0.5
        ps.append(ag.Param(d))
    out = f(*ps)
    loss = ag.tsum(ag.mul(out, ag.Tensor(np.asarray(rng.normal(size=out.shape)))) ) if out.data.ndim else out
    # fixed random projection so the check is non-trivial
    W = rng.normal(size=out.shape)
    loss = ag.tsum(ag.mul(f(*ps), ag.Tensor(W)))
    for p in ps:
        p.grad = None
    loss.backward()
    worst = 0.0
    for p in ps:
        an = p.grad.copy()
        num = np.zeros_like(p.data)
        it = np.nditer(p.data, flags=["multi_index"])
        for _ in it:
            i = it.multi_index
            old = p.data[i]
            p.data[i] = old + eps
            lp = float((f(*ps).data * W).sum())
            p.data[i] = old - eps
            lm = float((f(*ps).data * W).sum())
            p.data[i] = old
            num[i] = (lp - lm) / (2 * eps)
        err = np.abs(an - num).max() / (np.abs(num).max() + 1e-8)
        worst = max(worst, err)
    status = "OK " if worst < tol else "FAIL"
    print(f"[{status}] {name:<22s} rel.err={worst:.2e}")
    return worst < tol


ok = True
ok &= check("add(broadcast)", lambda a, b: ag.add(a, b), [(3, 4), (4,)])
ok &= check("sub(broadcast)", lambda a, b: ag.sub(a, b), [(2, 3, 4), (3, 1)])
ok &= check("mul(broadcast)", lambda a, b: ag.mul(a, b), [(2, 3, 4), (1, 3, 4)])
ok &= check("matmul(batched)", lambda a, b: ag.matmul(a, b), [(2, 3, 4), (4, 5)])
ok &= check("matmul(bb)", lambda a, b: ag.matmul(a, b), [(2, 3, 4), (2, 4, 5)])
ok &= check("exp", ag.exp, [(3, 4)])
ok &= check("log", ag.log, [(3, 4)], positive=True)
ok &= check("tanh", ag.tanh, [(3, 4)])
ok &= check("sigmoid", ag.sigmoid, [(3, 4)])
ok &= check("softplus", ag.softplus, [(3, 4)])
ok &= check("gelu", ag.gelu, [(3, 4)])
ok &= check("sum(axis)", lambda a: ag.tsum(a, axis=1), [(3, 4, 2)])
ok &= check("mean(axis,keep)", lambda a: ag.mean(a, axis=-1, keepdims=True), [(3, 4)])
ok &= check("reshape", lambda a: ag.reshape(a, (6, 2)), [(3, 4)])
ok &= check("transpose", lambda a: ag.transpose(a, (2, 0, 1)), [(2, 3, 4)])
ok &= check("getitem", lambda a: a[:, 1:3], [(3, 4)])
ok &= check("concat", lambda a, b: ag.concat([a, b], axis=-1), [(2, 3), (2, 2)])
ok &= check("softmax", lambda a: ag.softmax(a, -1), [(2, 3, 5)])
ok &= check("layernorm", lambda a, g, b: ag.layernorm(a, g, b), [(2, 3, 6), (6,), (6,)])
idx = rng.integers(0, 5, size=(2, 3))
ok &= check("embedding", lambda W: ag.embedding(W, idx), [(5, 4)])
ii = rng.integers(0, 4, size=(2, 3, 1))
jj = rng.integers(0, 4, size=(2, 1, 3))
ok &= check("gather2d", lambda M: ag.gather2d(M, ii, jj), [(4, 4)])
y = (rng.random((3, 4)) > 0.5).astype(float)
w = (rng.random((3, 4)) > 0.2).astype(float)
ok &= check("bce_with_logits", lambda x: ag.bce_with_logits(x, y, w), [(3, 4)])


def attn_block(q, k, v, bias):
    s = ag.add(ag.mul(ag.matmul(q, ag.transpose(k, (0, 2, 1))), 0.5), bias)
    return ag.matmul(ag.softmax(s, -1), v)


ok &= check("attention composite", attn_block, [(2, 3, 4), (2, 3, 4), (2, 3, 4), (3, 3)])
import models
Cc = rng.normal(size=(2, 1, 3, 4)); Mk = np.where(rng.random((3, 4)) > 0.3, 0.0, -1e9); Mk[:, 0] = 0
ok &= check("fused attn_probs", lambda q, k, c, s, gk: ag.attn_probs(q, k, 0.5, Mk, [(c, Cc)], (s, gk)),
            [(2, 2, 3, 5), (2, 2, 5, 4), (2, 2, 3, 1), (1, 2, 1, 1), (2, 1, 3, 4)])
ok &= check("fused LSTM (BPTT)", lambda x, w: models.lstm_op(x, w), [(2, 5, 12), (3, 12)])
print("ALL GRADIENT CHECKS PASSED" if ok else "SOME CHECKS FAILED")

"""Training / inference utilities for the neural KT models.

Objective (CAFE-KT, equity-aware):
    L = L_KT + lambda_ew * L_EW + lambda_eq * R_eq + lambda_G * mean|G|
    L_KT   : group-balanced BCE  = 0.5 * (BCE_group0 + BCE_group1)      (if balanced=True)
             otherwise the ordinary interaction-weighted BCE
    L_EW   : BCE of the early-warning (dropout) head at every valid position
    R_eq   : sum_g (mean_g p - mean_g y)^2   (group calibration-in-the-large penalty)
The equity group label is used ONLY inside the training loss; it is never a model input.
"""
import time

import numpy as np

import autograd as ag
from autograd import Adam, Tensor
from metrics import kt_metrics


DEFAULT = dict(lr=2e-3, wd=1e-5, bs=64, epochs=40, patience=6, lr_patience=2, lr_factor=0.5, ema=0.98,
               lambda_ew=0.3, lambda_eq=0.0, balanced=False, lambda_G=1e-3, clip=1.0, verbose=True)


def loss_fn(model, b, cfg, training=True):
    logit, ew = model.forward(b, training=training)
    m = b["m"]
    y = b["r"].astype(np.float32)
    g = b["g"]
    if cfg["balanced"] and (g == 1).any() and (g == 0).any():
        w0 = m * (g == 0)[:, None]
        w1 = m * (g == 1)[:, None]
        L = ag.mul(ag.add(ag.bce_with_logits(logit, y, w0), ag.bce_with_logits(logit, y, w1)), 0.5)
    else:
        L = ag.bce_with_logits(logit, y, m)
    if cfg["lambda_eq"] > 0 and (g == 1).any() and (g == 0).any():
        p = ag.sigmoid(logit)
        R = None
        for gg in [0, 1]:
            w = m * (g == gg)[:, None]
            pm = ag.mul(ag.tsum(ag.mul(p, Tensor(w))), 1.0 / w.sum())
            d = ag.sub(pm, float((y * w).sum() / w.sum()))
            sq = ag.mul(d, d)
            R = sq if R is None else ag.add(R, sq)
        L = ag.add(L, ag.mul(R, cfg["lambda_eq"]))
    if ew is not None and cfg["lambda_ew"] > 0:
        yd = np.broadcast_to(b["y_drop"][:, None], m.shape).astype(np.float32)
        L = ag.add(L, ag.mul(ag.bce_with_logits(ew, yd, m), cfg["lambda_ew"]))
    reg = model.reg_loss()
    if reg is not None and cfg["lambda_G"] > 0:
        L = ag.add(L, ag.mul(reg, cfg["lambda_G"]))
    return L


def predict(model, data, bs=128):
    N = data.n
    Lmax = data.q.shape[1]
    P = np.zeros((N, Lmax), np.float32)
    E = np.zeros((N, Lmax), np.float32)
    with ag.no_grad():
        for b in data.batches(bs):
            logit, ew = model.forward(b, training=False)
            Lb = logit.shape[1]
            P[b["idx"], :Lb] = ag._sig(logit.data)
            if ew is not None:
                E[b["idx"], :Lb] = ag._sig(ew.data)
    return P, E


def flat(data, P):
    s = data.m > 0
    g = np.broadcast_to(data.group[:, None], data.m.shape)[s]
    return data.r[s].astype(np.float32), P[s], g


def fit(model, D, cfg=None, seed=0, log=None):
    c = dict(DEFAULT)
    if cfg:
        c.update(cfg)
    rng = np.random.default_rng(seed)
    opt = Adam(model.params(), lr=c["lr"], wd=c["wd"], clip=c["clip"])
    best, best_sd, bad, hist = -1, None, 0, []
    params = model.params()
    ema = [p.data.copy() for p in params] if c["ema"] else None
    since_lr = 0
    t0 = time.time()
    for ep in range(c["epochs"]):
        te = time.time()
        tot, nb = 0.0, 0
        for b in D["train"].batches(c["bs"], rng, shuffle=True):
            L = loss_fn(model, b, c, training=True)
            opt.zero_grad()
            L.backward()
            opt.step()
            if ema is not None:
                for e, p in zip(ema, params):
                    e *= c["ema"]
                    e += (1 - c["ema"]) * p.data
            tot += float(L.data)
            nb += 1
        if ema is not None:          # evaluate with the exponential moving average of the weights
            live = model.state_dict()
            model.load_state_dict(ema)
        P, _ = predict(model, D["val"])
        y, p, _ = flat(D["val"], P)
        auc = kt_metrics(y, p)["AUC"]
        hist.append(dict(epoch=ep + 1, train_loss=tot / nb, val_auc=auc, sec=time.time() - te))
        msg = f"  [{model.name}] ep {ep + 1:2d} loss {tot / nb:.4f} val AUC {auc:.4f} ({time.time() - te:.1f}s)"
        if c["verbose"]:
            print(msg, flush=True)
        if log is not None:
            log.write(msg + "\n")
            log.flush()
        if auc > best + 1e-4:
            best, best_sd, bad, since_lr = auc, model.state_dict(), 0, 0
        else:
            bad += 1
            since_lr += 1
            if since_lr >= c["lr_patience"]:       # reduce-on-plateau schedule
                opt.lr *= c["lr_factor"]
                since_lr = 0
        if ema is not None:
            model.load_state_dict(live)
        if bad >= c["patience"]:
            break
    model.load_state_dict(best_sd)
    return dict(best_val_auc=best, epochs_run=len(hist), train_sec=time.time() - t0,
                sec_per_epoch=float(np.mean([h["sec"] for h in hist])), history=hist)

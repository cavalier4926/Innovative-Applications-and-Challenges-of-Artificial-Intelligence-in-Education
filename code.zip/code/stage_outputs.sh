#!/bin/bash
# Copy the deliverables into the staging area used to transfer them to the PC.
set -e
SRC=/home/claude/proj
DST=/mnt/user-data/outputs/EI_JA_zq010902
rm -rf "$DST"
mkdir -p "$DST"/{paper,figures,code,data/raw,results/tables,results/analyses,logs}
cp "$SRC"/README.md "$DST"/
cp "$SRC"/paper/*.docx "$SRC"/paper/*.pdf "$DST"/paper/ 2>/dev/null || true
cp "$SRC"/figures/*.png "$SRC"/figures/*.pdf "$DST"/figures/
cp "$SRC"/code/*.py "$SRC"/code/*.js "$SRC"/code/*.sh "$DST"/code/
cp "$SRC"/data/raw/* "$DST"/data/raw/
cp "$SRC"/results/tables/* "$DST"/results/tables/
cp "$SRC"/results/conformal/conformal.json "$DST"/results/analyses/conformal.json
cp "$SRC"/results/interpret/interpret.json "$DST"/results/analyses/interpret.json
cp "$SRC"/results/tutoring/tutoring_results.json "$DST"/results/analyses/tutoring_results.json
for f in "$SRC"/results/federated/*.json; do cp "$f" "$DST"/results/analyses/federated_$(basename "$f"); done
(cd "$SRC"/results && zip -qr "$DST"/results/runs_all_metrics_predictions_weights.zip runs)
cp "$SRC"/logs/gradcheck.log "$DST"/logs/
cat "$SRC"/logs/main_baselines.log "$SRC"/logs/main_cafe.log "$SRC"/logs/stage_w0.log "$SRC"/logs/stage_w1.log \
    "$SRC"/logs/federated.log "$SRC"/logs/tutoring.log > "$DST"/logs/run_logs.txt
find "$DST" -type f | wc -l
du -sh "$DST"

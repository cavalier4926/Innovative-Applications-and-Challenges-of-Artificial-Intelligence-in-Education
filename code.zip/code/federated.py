"""
Privacy experiment: school-level federated training of CAFE-KT with optional
differential privacy (DP-FedAvg with Poisson client sampling, update clipping and
Gaussian noise; McMahan et al., 2018).  Privacy loss is accounted with the Renyi-DP
bound of the Poisson-subsampled Gaussian mechanism (Mironov et al., 2019).

    python federated.py --mode fedavg            # no DP
    python federated.py --mode dp --sigma 1.0    # DP-FedAvg
"""
import argparse
import json
import os
import pickle
import time
from math import comb, log, exp

import numpy as np

import data as dmod
import models
import train
from run_experiments import CAFE_OBJ, eval_kt, RAW

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results", "federated")


def rdp_sampled_gaussian(q, sigma, alpha):
    """RDP of the Poisson-subsampled Gaussian mechanism for integer alpha >= 2 (Mironov et al. 2019)."""
    terms = [comb(alpha, k) * (1 - q) ** (alpha - k) * q ** k * exp((k * k - k) / (2 * sigma ** 2))
             for k in range(alpha + 1)]
    return log(sum(terms)) / (alpha - 1)


def epsilon(q, sigma, steps, delta):
    best = np.inf
    for a in range(2, 256):
        try:
            e = steps * rdp_sampled_gaussian(q, sigma, a) + log(1 / delta) / (a - 1)
        except OverflowError:
            break
        best = min(best, e)
    return float(best)


def flat_params(m):
    return [p.data.copy() for p in m.params()]


def run(mode, sigma, rounds, q, clip, seed, local_steps, local_bs, lr, unit="school"):
    os.makedirs(OUT, exist_ok=True)
    D, Q, K, inter, stud, sp = dmod.build(RAW, seed=seed)
    tr = D["train"]
    if unit == "school":
        schools = np.unique(tr.school)
        clients = {s: tr.subset(np.where(tr.school == s)[0]) for s in schools}
    else:                       # every learner is a client (learner-level privacy)
        schools = np.arange(tr.n)
        clients = {s: tr.subset(np.array([s])) for s in schools}
    n_cl = len(schools)
    m = models.make_model("CAFE-KT", Q, K, seed=seed)
    cfg = dict(train.DEFAULT, **CAFE_OBJ)
    rng = np.random.default_rng(seed)
    theta = flat_params(m)
    hist, best, best_theta = [], -1, None
    norms = []
    t0 = time.time()
    for r in range(rounds):
        sel = [s for s in schools if rng.random() < q]
        agg = [np.zeros_like(x) for x in theta]
        for s in sel:
            m.load_state_dict(theta)
            opt = train.Adam(m.params(), lr=lr, wd=cfg["wd"], clip=cfg["clip"])
            cd = clients[s]
            steps = 0
            while steps < local_steps:
                for b in cd.batches(local_bs, rng, shuffle=True):
                    L = train.loss_fn(m, b, cfg, training=True)
                    opt.zero_grad()
                    L.backward()
                    opt.step()
                    steps += 1
                    if steps >= local_steps:
                        break
            delta = [p.data - t for p, t in zip(m.params(), theta)]
            nrm = float(np.sqrt(sum((d.astype(np.float64) ** 2).sum() for d in delta)))
            norms.append(nrm)
            if mode == "dp":
                f = min(1.0, clip / (nrm + 1e-12))
                delta = [d * f for d in delta]
            for a, d in zip(agg, delta):
                a += d
        if mode == "dp":
            denom = q * n_cl
            for a in agg:
                a += rng.normal(0, sigma * clip, a.shape).astype(a.dtype)
            theta = [t + a / denom for t, a in zip(theta, agg)]
        elif sel:
            theta = [t + a / len(sel) for t, a in zip(theta, agg)]
        if (r + 1) % 10 == 0 or r == rounds - 1:
            m.load_state_dict(theta)
            P, _ = train.predict(m, D["val"])
            auc = eval_kt(D["val"], P)["AUC"]
            hist.append(dict(round=r + 1, val_auc=auc, sec=time.time() - t0))
            print(f"  [{mode} s={sigma}] round {r + 1} val AUC {auc:.4f} median|delta| {np.median(norms[-50:]):.3f}",
                  flush=True)
            if auc > best:
                best, best_theta = auc, [x.copy() for x in theta]
    m.load_state_dict(best_theta)
    P, _ = train.predict(m, D["test"])
    rec = dict(mode=mode, unit=unit, sigma=sigma, rounds=rounds, q=q, clip=clip, n_clients=int(n_cl),
               local_steps=local_steps, local_bs=local_bs, lr=lr, kt=eval_kt(D["test"], P), history=hist,
               median_update_norm=float(np.median(norms)), wall_sec=time.time() - t0)
    if mode == "dp":
        delta_dp = 1.0 / (n_cl ** 1.1)
        rec["delta"] = delta_dp
        rec["epsilon"] = epsilon(q, sigma, rounds, delta_dp)
    tag = f"{unit}_" + (mode if mode != "dp" else f"dp_sigma{sigma:g}")
    with open(os.path.join(OUT, f"{tag}.json"), "w") as f:
        json.dump(rec, f, indent=1)
    print(f"[done] federated {tag}: test AUC {rec['kt']['AUC']:.4f} eps={rec.get('epsilon')}", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="fedavg")
    ap.add_argument("--sigma", type=float, default=1.0)
    ap.add_argument("--rounds", type=int, default=150)
    ap.add_argument("--q", type=float, default=0.3)
    ap.add_argument("--clip", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--local_steps", type=int, default=4)
    ap.add_argument("--local_bs", type=int, default=16)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--unit", default="school", choices=["school", "learner"])
    a = ap.parse_args()
    run(a.mode, a.sigma, a.rounds, a.q, a.clip, a.seed, a.local_steps, a.local_bs, a.lr, a.unit)

"""
EduSim-GT: a ground-truth educational simulator used to generate the raw dataset
for the CAFE-KT study.

The simulator gives every quantity a model is supposed to learn a known true value
(prerequisite graph, concept-specific forgetting rates, the exact probability of a
correct answer at every step, the latent mastery of every concept). This makes it
possible to measure *how well* a model recovers educational structure, not only
how well it predicts.

Generative model (per student s, concept k, item q, time t in hours):
  * Concepts form a DAG of prerequisites (A[child, parent] = 1).
  * Item response (4-parameter-style IRT):
        logit = a_q * (theta_s + z_{s,k} + 0.35 * mean_{p in Pa(k)} z_{s,p} - b_q)
        P(correct) = c_q + (1 - c_q - slip_s) * sigmoid(logit)
  * Learning after each attempt (prerequisite-gated, saturating):
        dz = eta_s * g_k * (0.4 + 0.6 * readiness) * (1.0 if correct else 0.6) * max(0, 1 - z/3)
  * Forgetting between attempts (power of practice slows forgetting - spacing effect):
        z <- z * exp(-lambda_k * phi_s * dt_days / (1 + 0.5 * n_practice_{s,k}))
  * Access/equity groups: group 1 ("low-connectivity / under-resourced setting")
    has the SAME ability distribution as group 0 but longer, more irregular gaps
    between sessions and more response noise (higher slip). Group differences in
    outcomes therefore arise from access conditions, never from ability.
  * Disengagement (dropout) hazard at the end of each session depends on recent
    error rate (frustration) and the length of the last absence.

Usage:
    python simulator.py --n_students 4000 --seed 2026 --out ../data/raw
"""
import argparse
import json
import os

import numpy as np
import pandas as pd


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


class EduSimulator:
    def __init__(self, K=30, items_per_concept=15, n_schools=40, seed=2026,
                 max_len=120):
        self.rng = np.random.default_rng(seed)
        rng = self.rng
        self.K = K
        self.max_len = max_len
        self.n_schools = n_schools
        # ---------- prerequisite DAG ----------
        A = np.zeros((K, K), dtype=np.int8)  # A[child, parent]
        for k in range(1, K):
            n = rng.choice([0, 1, 2, 3], p=[0.15, 0.45, 0.30, 0.10])
            lo = max(0, k - 6)
            cand = np.arange(lo, k)
            n = min(n, len(cand))
            if n > 0:
                par = rng.choice(cand, size=n, replace=False)
                A[k, par] = 1
        self.A = A
        self.parents = [np.where(A[k])[0] for k in range(K)]
        # ---------- concept parameters ----------
        self.delta = rng.normal(0, 0.4, K) + 0.8 * (np.arange(K) / (K - 1)) + 0.4
        self.gain = rng.uniform(0.25, 0.60, K)
        self.lam = np.exp(rng.uniform(np.log(0.02), np.log(0.40), K))  # per day
        # ---------- items ----------
        self.Q = K * items_per_concept
        self.item_concept = np.repeat(np.arange(K), items_per_concept)
        self.b = self.delta[self.item_concept] + rng.normal(0, 0.5, self.Q)
        self.a = np.clip(rng.lognormal(np.log(1.5), 0.25, self.Q), 0.7, 3.0)
        self.c = rng.uniform(0.02, 0.18, self.Q)
        self.items_of = [np.where(self.item_concept == k)[0] for k in range(K)]
        # ---------- schools ----------
        # schools 0..29 mostly group 0, schools 30..39 mostly group 1
        self.school_g1_prob = np.where(np.arange(n_schools) < int(0.75 * n_schools), 0.10, 0.80)

    # ------------------------------------------------------------------
    def new_student(self, rng, group=None, school=None):
        if school is None:
            school = int(rng.integers(self.n_schools))
        if group is None:
            group = int(rng.random() < self.school_g1_prob[school])
        st = dict(
            school=school,
            group=group,
            theta=rng.normal(0, 1.2),
            eta=rng.lognormal(0, 0.3),
            phi=rng.lognormal(0, 0.3),
            slip=(0.04 if group == 0 else 0.11) + rng.uniform(-0.02, 0.02),
            z=np.zeros(self.K),
            npr=np.zeros(self.K),
            t=0.0,
        )
        return st

    def session_gap_hours(self, rng, group):
        if group == 0:
            d = rng.lognormal(np.log(1.2), 0.6)       # median ~1.2 days
        else:
            d = rng.lognormal(np.log(3.0), 0.9)       # median ~3 days, heavier tail
        return 24.0 * d

    def within_gap_hours(self, rng):
        return rng.exponential(2.0) / 60.0 + 0.5 / 60.0   # minutes -> hours

    def forget(self, st, dt_hours):
        if dt_hours <= 0:
            return
        days = dt_hours / 24.0
        st["z"] *= np.exp(-self.lam * st["phi"] * days / (1.0 + 0.5 * st["npr"]))

    def prereq_support(self, st, k):
        par = self.parents[k]
        return st["z"][par].mean() if len(par) else 0.0

    def p_correct(self, st, q):
        k = self.item_concept[q]
        logit = self.a[q] * (st["theta"] + st["z"][k] + 0.35 * self.prereq_support(st, k) - self.b[q])
        return self.c[q] + (1 - self.c[q] - st["slip"]) * sigmoid(logit)

    def p_correct_all(self, st):
        """true P(correct) for every item (used by oracle policy)."""
        pre = np.array([self.prereq_support(st, k) for k in range(self.K)])
        k = self.item_concept
        logit = self.a * (st["theta"] + st["z"][k] + 0.35 * pre[k] - self.b)
        return self.c + (1 - self.c - st["slip"]) * sigmoid(logit)

    def learn(self, st, q, correct):
        k = self.item_concept[q]
        par = self.parents[k]
        ready = sigmoid(2.0 * (st["z"][par] - 0.5)).mean() if len(par) else 1.0
        dz = st["eta"] * self.gain[k] * (0.4 + 0.6 * ready) * (1.0 if correct else 0.6)
        dz *= max(0.0, 1.0 - st["z"][k] / 3.0)
        st["z"][k] += dz
        st["npr"][k] += 1

    def mastery_score(self, st):
        """Post-test: mean over concepts of P(correct) on a reference item (a=1, b=delta_k, no guess/slip)."""
        pre = np.array([self.prereq_support(st, k) for k in range(self.K)])
        return float(sigmoid(st["theta"] + st["z"] + 0.35 * pre - self.delta).mean())

    def dropout_hazard(self, recent_err, last_gap_days):
        return sigmoid(-4.3 + 3.2 * recent_err + 0.45 * np.log1p(last_gap_days))

    # ------------------------------------------------------------------
    def simulate_logged_student(self, rng, sid):
        """Logged (business-as-usual) curriculum: teacher-paced linear curriculum with review."""
        st = self.new_student(rng)
        rows = []
        ptr, streak, attempts = 0, 0, 0
        n, sess = 0, 0
        last_gap_days = 0.0
        dropped = 0
        recent = []
        while n < self.max_len and ptr < self.K:
            sess_len = int(rng.poisson(8) + 3)
            for _ in range(sess_len):
                if n >= self.max_len or ptr >= self.K:
                    break
                if ptr > 0 and rng.random() < 0.25:
                    k = int(rng.integers(0, ptr))
                    review = True
                else:
                    k = ptr
                    review = False
                q = int(rng.choice(self.items_of[k]))
                p = self.p_correct(st, q)
                r = int(rng.random() < p)
                rows.append((sid, n, q, k, r, st["t"], sess, p))
                self.learn(st, q, r)
                recent.append(r)
                n += 1
                if not review:
                    attempts += 1
                    streak = streak + 1 if r else 0
                    if streak >= 3 or attempts >= 8:
                        ptr += 1
                        streak, attempts = 0, 0
                dt = self.within_gap_hours(rng)
                self.forget(st, dt)
                st["t"] += dt
            # end of session -> dropout check
            if n >= self.max_len or ptr >= self.K:
                break
            err = 1 - np.mean(recent[-10:])
            gap = self.session_gap_hours(rng, st["group"])
            h = self.dropout_hazard(err, last_gap_days)
            if rng.random() < h:
                dropped = 1
                break
            last_gap_days = gap / 24.0
            self.forget(st, gap)
            st["t"] += gap
            sess += 1
        info = dict(student_id=sid, school_id=st["school"], group=st["group"],
                    theta=st["theta"], eta=st["eta"], phi=st["phi"], slip=st["slip"],
                    n_interactions=n, dropout=dropped,
                    final_mastery=self.mastery_score(st))
        return rows, info

    def generate(self, n_students):
        rng = self.rng
        all_rows, infos = [], []
        for sid in range(n_students):
            rows, info = self.simulate_logged_student(rng, sid)
            all_rows.extend(rows)
            infos.append(info)
        inter = pd.DataFrame(all_rows, columns=["student_id", "seq_idx", "item_id", "concept_id",
                                                "correct", "timestamp_h", "session_id", "true_p"])
        students = pd.DataFrame(infos)
        return inter, students

    def export_structure(self, out):
        pd.DataFrame(dict(item_id=np.arange(self.Q), concept_id=self.item_concept,
                          difficulty=self.b, discrimination=self.a, guess=self.c)
                     ).to_csv(os.path.join(out, "items.csv"), index=False)
        pd.DataFrame(dict(concept_id=np.arange(self.K), base_difficulty=self.delta,
                          learning_gain=self.gain, forgetting_rate_per_day=self.lam,
                          n_prerequisites=self.A.sum(1))
                     ).to_csv(os.path.join(out, "concepts.csv"), index=False)
        ch, pa = np.where(self.A)
        pd.DataFrame(dict(child_concept=ch, parent_concept=pa)).to_csv(
            os.path.join(out, "prerequisite_edges.csv"), index=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_students", type=int, default=4000)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--out", default="../data/raw")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    sim = EduSimulator(seed=args.seed)
    inter, students = sim.generate(args.n_students)
    inter.to_csv(os.path.join(args.out, "interactions.csv"), index=False)
    students.to_csv(os.path.join(args.out, "students.csv"), index=False)
    sim.export_structure(args.out)
    summ = dict(
        n_students=int(len(students)), n_interactions=int(len(inter)),
        n_items=int(sim.Q), n_concepts=int(sim.K), n_prereq_edges=int(sim.A.sum()),
        mean_len=float(students.n_interactions.mean()),
        correct_rate=float(inter.correct.mean()),
        dropout_rate=float(students.dropout.mean()),
        group1_share=float(students.group.mean()),
        dropout_by_group=students.groupby("group").dropout.mean().to_dict(),
        correct_by_group=inter.merge(students[["student_id", "group"]]).groupby("group").correct.mean().to_dict(),
        len_by_group=students.groupby("group").n_interactions.mean().to_dict(),
        mastery_by_group=students.groupby("group").final_mastery.mean().to_dict(),
    )
    with open(os.path.join(args.out, "dataset_summary.json"), "w") as f:
        json.dump(summ, f, indent=2)
    print(json.dumps(summ, indent=2))


if __name__ == "__main__":
    main()

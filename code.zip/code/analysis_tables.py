"""Aggregate run results into the tables used in the paper (results/tables/*.csv + tables.json)."""
import glob
import json
import os

import numpy as np
import pandas as pd
from scipy import stats

ROOT = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(ROOT, "..", "results", "runs")
TAB = os.path.join(ROOT, "..", "results", "tables")
os.makedirs(TAB, exist_ok=True)


def load(stage):
    recs = []
    for f in sorted(glob.glob(os.path.join(RUNS, f"{stage}__*.json"))):
        with open(f) as fh:
            recs.append(json.load(fh))
    return recs


def ms(x, d=4):
    x = np.asarray(x, float)
    return f"{x.mean():.{d}f} ± {x.std(ddof=1) if len(x) > 1 else 0:.{d}f}"


def main_table(recs, order):
    rows, raw = [], {}
    for m in order:
        rs = [r for r in recs if r["job"]["model"] == m and "kt" in r]
        if not rs:
            continue
        raw[m] = {k: [r["kt"][k] for r in rs] for k in ["AUC", "ACC", "RMSE", "NLL", "ECE"]}
        rows.append(dict(Model=m, n_seeds=len(rs), **{k: ms(v) for k, v in raw[m].items()}))
    df = pd.DataFrame(rows)
    # paired t-tests vs CAFE-KT
    ref = raw.get("CAFE-KT")
    tests = []
    if ref:
        for m, v in raw.items():
            if m in ("CAFE-KT", "Oracle (true p)", "CAFE-KT-Acc"):
                continue
            a, b = np.array(ref["AUC"]), np.array(v["AUC"])
            n = min(len(a), len(b))
            d = a[:n] - b[:n]
            t, p = stats.ttest_rel(a[:n], b[:n])
            ci = stats.t.ppf(0.975, n - 1) * d.std(ddof=1) / np.sqrt(n)
            tests.append(dict(Comparison=f"CAFE-KT vs {m}", dAUC=f"{d.mean():+.4f}",
                              CI95=f"[{d.mean() - ci:+.4f}, {d.mean() + ci:+.4f}]", t=round(float(t), 2),
                              p=f"{p:.2e}"))
    return df, pd.DataFrame(tests), raw


def fairness_table(recs, order):
    rows = []
    for m in order:
        rs = [r for r in recs if r["job"]["model"] == m and "kt" in r]
        if not rs:
            continue
        g = lambda key, gg: [r["kt"]["group"][gg][key] for r in rs]
        orc = {r["job"]["seed"]: r for r in recs if r["job"]["model"] == "Oracle (true p)"}
        reg0 = [orc[r["job"]["seed"]]["kt"]["group"]["0"]["AUC"] - r["kt"]["group"]["0"]["AUC"] for r in rs]
        reg1 = [orc[r["job"]["seed"]]["kt"]["group"]["1"]["AUC"] - r["kt"]["group"]["1"]["AUC"] for r in rs]
        rows.append(dict(Model=m,
                         AUC_g0=ms(g("AUC", "0")), AUC_g1=ms(g("AUC", "1")),
                         Regret_g0=ms(reg0), Regret_g1=ms(reg1),
                         Excess_gap=ms(np.array(reg1) - np.array(reg0)),
                         AUC_gap=ms([r["kt"]["group"]["AUC_gap"] for r in rs]),
                         ABROCA=ms([r["kt"]["ABROCA"] for r in rs]),
                         ECE_g0=ms(g("ECE", "0")), ECE_g1=ms(g("ECE", "1")),
                         CITL_g0=ms(g("CITL", "0")), CITL_g1=ms(g("CITL", "1"))))
    return pd.DataFrame(rows)


def ew_table(recs, order):
    rows = []
    for m in order:
        rs = [r for r in recs if r["job"]["model"] == m and "ew" in r]
        if not rs:
            continue
        row = dict(Model=m)
        for t in ["10", "20", "40"]:
            row[f"AUC@{t}"] = ms([r["ew"][t]["AUC"] for r in rs], 3)
            row[f"F1@{t}"] = ms([r["ew"][t]["F1"] for r in rs], 3)
        row["FNR_gap@20"] = ms([r["ew"]["20"]["FNR_gap"] for r in rs], 3)
        rows.append(row)
    return pd.DataFrame(rows)


def simple_table(recs, keys=("AUC", "ACC", "RMSE", "ECE")):
    by = {}
    for r in recs:
        by.setdefault(r["job"]["model"], []).append(r)
    rows = []
    for m, rs in by.items():
        row = dict(Model=m, n_seeds=len(rs))
        for k in keys:
            row[k] = ms([r["kt"][k] for r in rs])
        row["AUC_gap"] = ms([r["kt"]["group"]["AUC_gap"] for r in rs])
        row["ECE_g1"] = ms([r["kt"]["group"]["1"]["ECE"] for r in rs])
        row["|CITL_g1|"] = ms([abs(r["kt"]["group"]["1"]["CITL"]) for r in rs])
        if "ew" in rs[0]:
            row["EW_AUC@20"] = ms([r["ew"]["20"]["AUC"] for r in rs], 3)
        rows.append(row)
    return pd.DataFrame(rows)


def efficiency(recs, order):
    rows = []
    for m in order:
        rs = [r for r in recs if r["job"]["model"] == m and "kt" in r]
        if not rs:
            continue
        row = dict(Model=m)
        if "n_params" in rs[0]:
            row["Params"] = rs[0]["n_params"]
            row["sec/epoch"] = f"{np.mean([r['train']['sec_per_epoch'] for r in rs]):.1f}"
            row["epochs"] = f"{np.mean([r['train']['epochs_run'] for r in rs]):.1f}"
            row["train_min"] = f"{np.mean([r['train']['train_sec'] for r in rs]) / 60:.1f}"
            row["ms_per_1k_pred"] = f"{1000 * np.mean([r['infer_sec_test'] / r['n_test_predictions'] * 1000 for r in rs]):.2f}"
        else:
            row["Params"] = "-"
            row["train_min"] = f"{np.mean([r.get('train_sec', np.nan) for r in rs]) / 60:.2f}"
        rows.append(row)
    return pd.DataFrame(rows)


def oracle_rows():
    """Bayes ceiling: the simulator's true success probabilities on each seed's test split."""
    import data as dmod
    from metrics import kt_metrics, group_metrics
    recs = []
    for seed in range(5):
        D, *_ = dmod.build(os.path.join(ROOT, "..", "data", "raw"), seed=seed)
        s = D["test"].m > 0
        y = D["test"].r[s].astype(float)
        p = D["test"].p_true[s]
        g = np.broadcast_to(D["test"].group[:, None], D["test"].m.shape)[s]
        kt = kt_metrics(y, p)
        kt["group"] = {str(k): v for k, v in group_metrics(y, p, g).items()}
        from metrics import abroca
        kt["ABROCA"] = abroca(y, p, g)
        recs.append(dict(job=dict(model="Oracle (true p)", seed=seed), kt=kt))
    return recs


if __name__ == "__main__":
    main = load("main")
    orc = oracle_rows()
    json.dump(orc, open(os.path.join(TAB, "oracle.json"), "w"))
    acc = [dict(r, job=dict(r["job"], model="CAFE-KT-Acc")) for r in load("ablation")
           if r["job"]["model"] == "CAFE-KT w/o equity objective"]
    main = main + orc + acc
    order = ["BKT", "PFA", "GBDT-FE", "DKT", "SAKT", "AKT-s", "CAFE-KT-Acc", "CAFE-KT", "Oracle (true p)"]
    out = {}
    t1, t1s, raw = main_table(main, order)
    t1.to_csv(os.path.join(TAB, "table_main.csv"), index=False)
    t1s.to_csv(os.path.join(TAB, "table_main_tests.csv"), index=False)
    fairness_table(main, order).to_csv(os.path.join(TAB, "table_fairness.csv"), index=False)
    ew_table(main, ["EW-LR", "EW-GBDT", "DKT", "SAKT", "AKT-s", "CAFE-KT"]).to_csv(
        os.path.join(TAB, "table_early_warning.csv"), index=False)
    efficiency(main, order[:-1]).to_csv(os.path.join(TAB, "table_efficiency.csv"), index=False)
    abl = load("ablation") + [r for r in main if r["job"]["model"] == "CAFE-KT" and r["job"]["seed"] < 3]
    simple_table(abl).to_csv(os.path.join(TAB, "table_ablation.csv"), index=False)
    eq = load("equity") + [r for r in main if r["job"]["model"] == "CAFE-KT" and r["job"]["seed"] < 2] + \
        [r for r in load("ablation") if r["job"]["model"] == "CAFE-KT w/o equity objective" and r["job"]["seed"] < 2]
    simple_table(eq).to_csv(os.path.join(TAB, "table_equity.csv"), index=False)
    # sparsity
    sp = load("sparsity")
    rows = []
    for r in sp + [r for r in main if r["job"]["model"] in ["GBDT-FE", "SAKT", "AKT-s", "CAFE-KT"] and r["job"]["seed"] < 2]:
        rows.append(dict(model=r["job"]["model"], frac=r["job"].get("frac", 1.0), seed=r["job"]["seed"],
                         AUC=r["kt"]["AUC"], n_train=r["n_train_students"]))
    pd.DataFrame(rows).to_csv(os.path.join(TAB, "sparsity_raw.csv"), index=False)
    for f in sorted(glob.glob(os.path.join(TAB, "*.csv"))):
        print("\n==", os.path.basename(f))
        try:
            print(pd.read_csv(f).to_string(index=False))
        except Exception:
            print("(empty)")

"""
Minimal reverse-mode automatic differentiation on NumPy arrays.

Written so the whole study runs on any machine with NumPy only (no GPU or deep
learning framework needed). Every operator below is verified against finite
differences in `test_autograd.py`.
"""
import numpy as np
import scipy.sparse as _sp

DTYPE = np.float32
_GRAD_ENABLED = [True]


class no_grad:
    def __enter__(self):
        self.prev = _GRAD_ENABLED[0]
        _GRAD_ENABLED[0] = False

    def __exit__(self, *a):
        _GRAD_ENABLED[0] = self.prev


class Tensor:
    __slots__ = ("data", "grad", "_parents", "_back", "requires_grad", "name")

    def __init__(self, data, parents=(), back=None, requires_grad=False, name=None):
        self.data = data
        self.grad = None
        self.name = name
        rg = requires_grad or (_GRAD_ENABLED[0] and any(p.requires_grad for p in parents))
        self.requires_grad = rg
        if rg and _GRAD_ENABLED[0] and parents:
            self._parents = parents
            self._back = back
        else:
            self._parents = ()
            self._back = None

    @property
    def shape(self):
        return self.data.shape

    def __repr__(self):
        return f"Tensor(shape={self.data.shape})"

    # operator sugar
    def __add__(self, o): return add(self, o)
    def __radd__(self, o): return add(o, self)
    def __sub__(self, o): return sub(self, o)
    def __rsub__(self, o): return sub(o, self)
    def __mul__(self, o): return mul(self, o)
    def __rmul__(self, o): return mul(o, self)
    def __neg__(self): return mul(self, -1.0)
    def __matmul__(self, o): return matmul(self, o)
    def __getitem__(self, idx): return getitem(self, idx)

    def backward(self, grad=None):
        topo, seen = [], set()

        def build(t):
            stack = [(t, False)]
            while stack:
                node, done = stack.pop()
                if done:
                    topo.append(node)
                    continue
                if id(node) in seen:
                    continue
                seen.add(id(node))
                stack.append((node, True))
                for p in node._parents:
                    if id(p) not in seen:
                        stack.append((p, False))
        build(self)
        self.grad = np.ones_like(self.data) if grad is None else grad
        for node in reversed(topo):
            if node._back is not None and node.grad is not None:
                node._back(node.grad)
                # free intermediate graph memory
                if node._parents:
                    node._back = None


def as_tensor(x):
    if isinstance(x, Tensor):
        return x
    return Tensor(np.asarray(x, dtype=DTYPE))


def _acc(t, g):
    if not t.requires_grad:
        return
    if t.grad is None:
        t.grad = g.copy() if g.base is not None or g is t.data else g
    else:
        t.grad = t.grad + g


def _unbroadcast(g, shape):
    if g.shape == shape:
        return g
    nd = g.ndim - len(shape)
    if nd > 0:
        g = g.sum(axis=tuple(range(nd)))
    axes = tuple(i for i, s in enumerate(shape) if s == 1 and g.shape[i] != 1)
    if axes:
        g = g.sum(axis=axes, keepdims=True)
    return g.reshape(shape)


# ---------------------------------------------------------------- elementwise
def add(a, b):
    a, b = as_tensor(a), as_tensor(b)
    out = Tensor(a.data + b.data, (a, b))

    def back(g):
        _acc(a, _unbroadcast(g, a.shape))
        _acc(b, _unbroadcast(g, b.shape))
    out._back = back if out._parents else None
    return out


def sub(a, b):
    a, b = as_tensor(a), as_tensor(b)
    out = Tensor(a.data - b.data, (a, b))

    def back(g):
        _acc(a, _unbroadcast(g, a.shape))
        _acc(b, _unbroadcast(-g, b.shape))
    out._back = back if out._parents else None
    return out


def mul(a, b):
    a, b = as_tensor(a), as_tensor(b)
    out = Tensor(a.data * b.data, (a, b))

    def back(g):
        if a.requires_grad:
            _acc(a, _unbroadcast(g * b.data, a.shape))
        if b.requires_grad:
            _acc(b, _unbroadcast(g * a.data, b.shape))
    out._back = back if out._parents else None
    return out


def _unary(a, fwd, dfn):
    a = as_tensor(a)
    y = fwd(a.data)
    out = Tensor(y, (a,))

    def back(g):
        _acc(a, g * dfn(a.data, y))
    out._back = back if out._parents else None
    return out


def exp(a): return _unary(a, np.exp, lambda x, y: y)
def log(a): return _unary(a, np.log, lambda x, y: 1.0 / x)
def tanh(a): return _unary(a, np.tanh, lambda x, y: 1 - y * y)
def relu(a): return _unary(a, lambda x: np.maximum(x, 0), lambda x, y: (x > 0).astype(x.dtype))
def absval(a): return _unary(a, np.abs, lambda x, y: np.sign(x))


def _sig(x):
    return 0.5 * (1.0 + np.tanh(0.5 * x))


def sigmoid(a): return _unary(a, _sig, lambda x, y: y * (1 - y))
def softplus(a): return _unary(a, lambda x: np.logaddexp(0, x), lambda x, y: _sig(x))


def gelu(a):
    c = float(np.sqrt(2 / np.pi))

    def f(x):
        return 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x * x * x)))

    def d(x, y):
        u = c * (x + 0.044715 * x * x * x)
        t = np.tanh(u)
        return 0.5 * (1 + t) + 0.5 * x * (1 - t * t) * c * (1 + 3 * 0.044715 * x * x)
    return _unary(a, f, d)


# ---------------------------------------------------------------- reductions / shape
def tsum(a, axis=None, keepdims=False):
    a = as_tensor(a)
    out = Tensor(a.data.sum(axis=axis, keepdims=keepdims), (a,))

    def back(g):
        if axis is not None and not keepdims:
            g = np.expand_dims(g, axis)
        _acc(a, np.broadcast_to(g, a.shape).astype(a.data.dtype))
    out._back = back if out._parents else None
    return out


def mean(a, axis=None, keepdims=False):
    a = as_tensor(a)
    n = a.data.size if axis is None else np.prod([a.shape[i] for i in np.atleast_1d(axis)])
    return mul(tsum(a, axis, keepdims), 1.0 / n)


def reshape(a, shape):
    a = as_tensor(a)
    out = Tensor(a.data.reshape(shape), (a,))

    def back(g):
        _acc(a, g.reshape(a.shape))
    out._back = back if out._parents else None
    return out


def transpose(a, axes):
    a = as_tensor(a)
    out = Tensor(a.data.transpose(axes), (a,))
    inv = np.argsort(axes)

    def back(g):
        _acc(a, g.transpose(inv))
    out._back = back if out._parents else None
    return out


def getitem(a, idx):
    a = as_tensor(a)
    out = Tensor(a.data[idx], (a,))

    def back(g):
        full = np.zeros_like(a.data)
        full[idx] += g
        _acc(a, full)
    out._back = back if out._parents else None
    return out


def concat(ts, axis=-1):
    ts = [as_tensor(t) for t in ts]
    out = Tensor(np.concatenate([t.data for t in ts], axis=axis), tuple(ts))
    sizes = np.cumsum([t.shape[axis] for t in ts])[:-1]

    def back(g):
        parts = np.split(g, sizes, axis=axis)
        for t, p in zip(ts, parts):
            _acc(t, p)
    out._back = back if out._parents else None
    return out


# ---------------------------------------------------------------- linear algebra
def matmul(a, b):
    a, b = as_tensor(a), as_tensor(b)
    out = Tensor(np.matmul(a.data, b.data), (a, b))

    def back(g):
        if a.requires_grad:
            ga = np.matmul(g, np.swapaxes(b.data, -1, -2)) if b.data.ndim > 1 else np.outer(g, b.data)
            _acc(a, _unbroadcast(ga, a.shape))
        if b.requires_grad:
            if b.data.ndim == 2 and a.data.ndim > 2:
                gb = a.data.reshape(-1, a.shape[-1]).T @ g.reshape(-1, g.shape[-1])
            else:
                gb = np.matmul(np.swapaxes(a.data, -1, -2), g)
            _acc(b, _unbroadcast(gb, b.shape))
    out._back = back if out._parents else None
    return out


def attn_probs(q, kT, scale, mask, lin_terms=(), graph_term=None):
    """Fused attention probabilities with structural biases.
        S = scale * q @ kT + sum_i coef_i * C_i + s * Gk + mask ;  A = softmax(S)
    q: (B,H,Lq,dh) Tensor, kT: (B,H,dh,Lk) Tensor, mask: numpy (.., Lq, Lk)
    lin_terms: list of (coef Tensor broadcastable to (B,H,Lq,1), C numpy (B|1,1,Lq,Lk))
    graph_term: (s Tensor (1,H,1,1), Gk Tensor (B,1,Lq,Lk)) or None
    """
    scale = float(scale)
    S = np.matmul(q.data, kT.data) * scale
    for coef, C in lin_terms:
        S += coef.data * C
    if graph_term is not None:
        S += graph_term[0].data * graph_term[1].data
    S += mask
    S -= S.max(-1, keepdims=True)
    np.exp(S, out=S)
    S /= S.sum(-1, keepdims=True)
    A = S
    parents = [q, kT] + [c for c, _ in lin_terms] + (list(graph_term) if graph_term is not None else [])
    out = Tensor(A, tuple(parents))

    def back(gA):
        dS = A * (gA - (gA * A).sum(-1, keepdims=True))
        if q.requires_grad:
            _acc(q, np.matmul(dS, np.swapaxes(kT.data, -1, -2)) * scale)
        if kT.requires_grad:
            _acc(kT, np.matmul(np.swapaxes(q.data, -1, -2), dS) * scale)
        for coef, C in lin_terms:
            if coef.requires_grad:
                gc = (dS * C).sum(-1, keepdims=True)
                _acc(coef, _unbroadcast(gc, coef.shape))
        if graph_term is not None:
            s, Gk = graph_term
            if s.requires_grad:
                _acc(s, _unbroadcast(dS * Gk.data, s.shape))
            if Gk.requires_grad:
                _acc(Gk, _unbroadcast(dS * s.data, Gk.shape))
    out._back = back if out._parents else None
    return out


def embedding(W, idx):
    """W: (V, d) parameter, idx: int array of any shape -> (..., d)."""
    out = Tensor(W.data[idx], (W,))

    def back(g):
        fi = idx.reshape(-1)
        n = fi.size
        oh = _sp.csr_matrix((np.ones(n, dtype=g.dtype), (fi, np.arange(n))), shape=(W.shape[0], n))
        gw = np.asarray(oh @ g.reshape(n, W.shape[1]), dtype=W.data.dtype)
        _acc(W, gw)
    out._back = back if out._parents else None
    return out


def gather2d(M, i_idx, j_idx):
    """M: (K, K) parameter; returns M[i_idx, j_idx] (broadcast shapes). Fast bincount backward."""
    K1, K2 = M.shape
    flat = (i_idx * K2 + j_idx)
    out = Tensor(M.data.reshape(-1)[flat], (M,))

    def back(g):
        gm = np.bincount(flat.reshape(-1), weights=g.reshape(-1).astype(np.float64),
                         minlength=K1 * K2).reshape(K1, K2).astype(M.data.dtype)
        _acc(M, gm)
    out._back = back if out._parents else None
    return out


# ---------------------------------------------------------------- fused nn ops
def softmax(a, axis=-1):
    a = as_tensor(a)
    x = a.data - a.data.max(axis=axis, keepdims=True)
    e = np.exp(x)
    y = e / e.sum(axis=axis, keepdims=True)
    out = Tensor(y, (a,))

    def back(g):
        _acc(a, y * (g - (g * y).sum(axis=axis, keepdims=True)))
    out._back = back if out._parents else None
    return out


def layernorm(a, gamma, beta, eps=1e-5):
    a = as_tensor(a)
    mu = a.data.mean(-1, keepdims=True)
    xc = a.data - mu
    var = (xc * xc).mean(-1, keepdims=True)
    inv = 1.0 / np.sqrt(var + eps)
    xh = xc * inv
    out = Tensor(xh * gamma.data + beta.data, (a, gamma, beta))
    D = a.shape[-1]

    def back(g):
        if gamma.requires_grad:
            _acc(gamma, (g * xh).reshape(-1, D).sum(0))
        if beta.requires_grad:
            _acc(beta, g.reshape(-1, D).sum(0))
        if a.requires_grad:
            gx = g * gamma.data
            dx = inv * (gx - gx.mean(-1, keepdims=True) - xh * (gx * xh).mean(-1, keepdims=True))
            _acc(a, dx)
    out._back = back if out._parents else None
    return out


def dropout(a, p, training, rng):
    if not training or p <= 0:
        return a
    mask = (rng.random(a.shape) >= p).astype(a.data.dtype) / (1 - p)
    return mul(a, Tensor(mask))


def bce_with_logits(logits, y, w):
    """weighted mean binary cross-entropy. y, w are numpy arrays (no grad)."""
    x = logits.data
    sw = w.sum() + 1e-8
    l = np.logaddexp(0, x) - y * x
    out = Tensor(np.asarray((w * l).sum() / sw, dtype=x.dtype), (logits,))

    def back(g):
        _acc(logits, (g * w * (_sig(x) - y) / sw).astype(x.dtype))
    out._back = back if out._parents else None
    return out


# ---------------------------------------------------------------- modules / optim
class Param(Tensor):
    def __init__(self, data, name=None):
        super().__init__(np.asarray(data, dtype=DTYPE), requires_grad=True, name=name)


class Module:
    def params(self):
        out = []
        for k, v in self.__dict__.items():
            if isinstance(v, Param):
                out.append(v)
            elif isinstance(v, Module):
                out.extend(v.params())
            elif isinstance(v, (list, tuple)):
                for x in v:
                    if isinstance(x, Module):
                        out.extend(x.params())
                    elif isinstance(x, Param):
                        out.append(x)
        return out

    def n_params(self):
        return int(sum(p.data.size for p in self.params()))

    def state_dict(self):
        return [p.data.copy() for p in self.params()]

    def load_state_dict(self, sd):
        for p, d in zip(self.params(), sd):
            p.data[...] = d


def xavier(rng, fan_in, fan_out, shape=None):
    s = np.sqrt(6.0 / (fan_in + fan_out))
    return rng.uniform(-s, s, shape or (fan_in, fan_out)).astype(DTYPE)


class Linear(Module):
    def __init__(self, rng, din, dout, bias=True):
        self.W = Param(xavier(rng, din, dout))
        self.b = Param(np.zeros(dout)) if bias else None

    def __call__(self, x):
        y = matmul(x, self.W)
        return add(y, self.b) if self.b is not None else y

    def params(self):
        return [self.W] + ([self.b] if self.b is not None else [])


class LayerNorm(Module):
    def __init__(self, d):
        self.g = Param(np.ones(d))
        self.b = Param(np.zeros(d))

    def __call__(self, x):
        return layernorm(x, self.g, self.b)


class Adam:
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, wd=0.0, clip=1.0):
        self.p = params
        self.lr, self.b1, self.b2, self.eps, self.wd, self.clip = lr, betas[0], betas[1], eps, wd, clip
        self.m = [np.zeros_like(p.data) for p in params]
        self.v = [np.zeros_like(p.data) for p in params]
        self.t = 0

    def zero_grad(self):
        for p in self.p:
            p.grad = None

    def step(self):
        self.t += 1
        grads = [p.grad if p.grad is not None else np.zeros_like(p.data) for p in self.p]
        if self.clip:
            tot = np.sqrt(sum(float((g.astype(np.float64) ** 2).sum()) for g in grads))
            if tot > self.clip:
                grads = [g * (self.clip / (tot + 1e-12)) for g in grads]
        lr_t = self.lr * np.sqrt(1 - self.b2 ** self.t) / (1 - self.b1 ** self.t)
        for p, g, m, v in zip(self.p, grads, self.m, self.v):
            if self.wd and p.data.ndim > 1:
                g = g + self.wd * p.data
            m *= self.b1
            m += (1 - self.b1) * g
            v *= self.b2
            v += (1 - self.b2) * g * g
            p.data -= (lr_t * m / (np.sqrt(v) + self.eps)).astype(p.data.dtype)

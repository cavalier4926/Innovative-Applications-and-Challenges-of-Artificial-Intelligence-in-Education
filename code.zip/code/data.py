"""Data loading, student-level splitting and padding for knowledge-tracing models.

Input format (works for the simulated data and for any real log in the same schema):
  interactions.csv : student_id, seq_idx, item_id, concept_id, correct, timestamp_h
  students.csv     : student_id, group, dropout, school_id
"""
import os

import numpy as np
import pandas as pd

MAX_LEN = 120


def load_raw(root):
    inter = pd.read_csv(os.path.join(root, "interactions.csv"))
    stud = pd.read_csv(os.path.join(root, "students.csv"))
    inter = inter.sort_values(["student_id", "seq_idx"]).reset_index(drop=True)
    return inter, stud


def split_students(stud, seed, frac=(0.6, 0.1, 0.1, 0.2)):
    """Stratified (by equity group) student-level split: train / val / calib / test."""
    rng = np.random.default_rng(seed)
    parts = {"train": [], "val": [], "calib": [], "test": []}
    for g, d in stud.groupby("group"):
        ids = d.student_id.values.copy()
        rng.shuffle(ids)
        n = len(ids)
        c = np.cumsum([int(round(f * n)) for f in frac])
        parts["train"] += list(ids[:c[0]])
        parts["val"] += list(ids[c[0]:c[1]])
        parts["calib"] += list(ids[c[1]:c[2]])
        parts["test"] += list(ids[c[2]:])
    return {k: np.array(sorted(v)) for k, v in parts.items()}


N_FEAT = 8


def _feat_row(nk, ck, lrk, ltk, has, tm, t_prev, n_all, c_all, rec):
    return [np.log1p(nk) / np.log(121.0), (ck + 1) / (nk + 2), lrk if has else 0.5,
            np.log1p(max(tm - ltk, 0)) / 8.0 if has else 1.0, float(has),
            np.log1p(max(tm - t_prev, 0)) / 8.0 if t_prev is not None else 0.0,
            (c_all + 1) / (n_all + 2), np.mean(rec[-5:]) if rec else 0.5]


def query_features(q, k, r, t, m):
    """Causal forgetting-aware query features for every position (uses only attempts before it):
    practice count on the concept, smoothed success rate on the concept, last outcome on the concept,
    log time since the last attempt on the concept, first-encounter flag, log time since the previous
    attempt, smoothed overall success rate, success rate over the last 5 attempts."""
    N, L = q.shape
    F = np.zeros((N, L, N_FEAT), np.float32)
    K = int(k.max()) + 1
    for i in range(N):
        nk = np.zeros(K); ck = np.zeros(K); lr = np.zeros(K); lt = np.zeros(K)
        rec = []
        for j in range(int(m[i].sum())):
            kk = k[i, j]
            F[i, j] = _feat_row(nk[kk], ck[kk], lr[kk], lt[kk], nk[kk] > 0, t[i, j],
                                t[i, j - 1] if j > 0 else None, len(rec), sum(rec), rec)
            nk[kk] += 1; ck[kk] += r[i, j]; lr[kk] = r[i, j]; lt[kk] = t[i, j]
            rec.append(r[i, j])
    return F


def candidate_features(hq, hk, hr, ht, cand_k, t_now, K):
    """Query features for all candidate concepts given histories (B,s) -> (B,C,N_FEAT)."""
    B, s = hk.shape
    C = len(cand_k)
    out = np.zeros((B, C, N_FEAT), np.float32)
    for b in range(B):
        nk = np.bincount(hk[b], minlength=K).astype(float)
        ck = np.bincount(hk[b], weights=hr[b], minlength=K)
        lr = np.full(K, 0.5); lt = np.zeros(K)
        for j in range(s):
            lr[hk[b, j]] = hr[b, j]; lt[hk[b, j]] = ht[b, j]
        rec = list(hr[b])
        n_all, c_all = s, float(np.sum(hr[b]))
        per_k = np.array([_feat_row(nk[kk], ck[kk], lr[kk], lt[kk], nk[kk] > 0, t_now[b],
                                    ht[b, -1] if s > 0 else None, n_all, c_all, rec) for kk in range(K)],
                         np.float32)
        out[b] = per_k[cand_k]
    return out


class SeqData:
    """Padded arrays for a set of students."""

    def __init__(self, inter, stud, ids, max_len=MAX_LEN):
        sub = inter[inter.student_id.isin(ids)]
        smap = stud.set_index("student_id")
        n = len(ids)
        self.ids = np.asarray(ids)
        self.q = np.zeros((n, max_len), np.int64)
        self.k = np.zeros((n, max_len), np.int64)
        self.r = np.zeros((n, max_len), np.int64)
        self.t = np.zeros((n, max_len), np.float32)
        self.m = np.zeros((n, max_len), np.float32)
        self.p_true = np.zeros((n, max_len), np.float32)
        pos = {s: i for i, s in enumerate(ids)}
        for sid, d in sub.groupby("student_id"):
            i = pos[sid]
            L = min(len(d), max_len)
            self.q[i, :L] = d.item_id.values[:L]
            self.k[i, :L] = d.concept_id.values[:L]
            self.r[i, :L] = d.correct.values[:L]
            self.t[i, :L] = d.timestamp_h.values[:L]
            self.m[i, :L] = 1
            if "true_p" in d:
                self.p_true[i, :L] = d.true_p.values[:L]
        self.f = query_features(self.q, self.k, self.r, self.t, self.m)
        self.group = smap.loc[ids, "group"].values.astype(np.int64)
        self.dropout = smap.loc[ids, "dropout"].values.astype(np.float32)
        self.school = smap.loc[ids, "school_id"].values.astype(np.int64)
        self.length = self.m.sum(1).astype(np.int64)
        self.n = n

    def subset(self, idx):
        o = object.__new__(SeqData)
        for a in ["ids", "q", "k", "r", "t", "m", "f", "p_true", "group", "dropout", "school", "length"]:
            setattr(o, a, getattr(self, a)[idx])
        o.n = len(idx)
        return o

    def batches(self, bs, rng=None, shuffle=False):
        idx = np.arange(self.n)
        if shuffle:
            rng.shuffle(idx)
        for s in range(0, self.n, bs):
            b = idx[s:s + bs]
            Lb = int(self.length[b].max())
            yield dict(q=self.q[b, :Lb], k=self.k[b, :Lb], r=self.r[b, :Lb], t=self.t[b, :Lb],
                       m=self.m[b, :Lb], f=self.f[b, :Lb], g=self.group[b], y_drop=self.dropout[b], idx=b)


def build(root, seed, max_len=MAX_LEN, train_frac=1.0):
    inter, stud = load_raw(root)
    sp = split_students(stud, seed)
    if train_frac < 1.0:
        rng = np.random.default_rng(seed + 99)
        tr = sp["train"].copy()
        rng.shuffle(tr)
        sp["train"] = np.sort(tr[:max(20, int(train_frac * len(tr)))])
    out = {k: SeqData(inter, stud, v, max_len) for k, v in sp.items()}
    n_items = int(inter.item_id.max()) + 1
    n_concepts = int(inter.concept_id.max()) + 1
    return out, n_items, n_concepts, inter, stud, sp

"""
Neural knowledge-tracing models (NumPy autograd).

  * CAFE-KT (proposed): Concept-graph Attention with Forgetting-decay and Equity
      - Rasch-style item embeddings (sparse-item robustness)
      - knowledge encoder + knowledge retriever (2 attention blocks)
      - every attention logit receives two structural, interpretable biases
            b_time  = - softplus(w_h + u_{k_query}) * log(1 + dt_hours)   (concept-specific
                      power-law forgetting kernel on real elapsed time)
            b_graph =   s_h * G[k_query, k_key]                           (learnable directed
                      concept-relation matrix; L1-sparse; read out as a prerequisite graph)
      - multi-task head for early warning of disengagement (dropout)
      - trained with an equity-aware objective (group-balanced loss + group
        calibration-in-the-large penalty), see train.py
  * SAKT  : self-attentive KT (item embeddings, 1 retriever block, no structural bias)
  * AKT-s : simplified AKT-style model (Rasch embeddings, encoder+retriever,
            monotonic position-distance decay)
  * DKT   : LSTM knowledge tracing (fused BPTT op)
All share the same embedding size / heads so differences come from the mechanisms.
"""
import numpy as np

import autograd as ag
from data import N_FEAT, candidate_features
from autograd import Module, Param, Linear, LayerNorm, Tensor

NEG = -1e9


def inv_softplus(y):
    return float(np.log(np.expm1(y)))


class MHA(Module):
    def __init__(self, rng, d, H):
        self.H, self.dh = H, d // H
        self.Wq = Linear(rng, d, d)
        self.Wk = Linear(rng, d, d)
        self.Wv = Linear(rng, d, d)
        self.Wo = Linear(rng, d, d)
        self.last_attn = None

    def __call__(self, xq, xkv, bias, mask_add):
        B, Lq, d = xq.shape
        Lk = xkv.shape[1]
        H, dh = self.H, self.dh
        q = ag.transpose(ag.reshape(self.Wq(xq), (B, Lq, H, dh)), (0, 2, 1, 3))
        k = ag.transpose(ag.reshape(self.Wk(xkv), (B, Lk, H, dh)), (0, 2, 3, 1))
        v = ag.transpose(ag.reshape(self.Wv(xkv), (B, Lk, H, dh)), (0, 2, 1, 3))
        lin, gt = bias if bias is not None else ((), None)
        a = ag.attn_probs(q, k, 1.0 / np.sqrt(dh), mask_add, lin, gt)
        self.last_attn = a.data
        o = ag.matmul(a, v)
        o = ag.reshape(ag.transpose(o, (0, 2, 1, 3)), (B, Lq, d))
        return self.Wo(o)


class FFN(Module):
    def __init__(self, rng, d, mult=2):
        self.l1 = Linear(rng, d, d * mult)
        self.l2 = Linear(rng, d * mult, d)

    def __call__(self, x):
        return self.l2(ag.gelu(self.l1(x)))


class Block(Module):
    def __init__(self, rng, d, H, p_drop):
        self.att = MHA(rng, d, H)
        self.ln1 = LayerNorm(d)
        self.ffn = FFN(rng, d)
        self.ln2 = LayerNorm(d)
        self.p = p_drop

    def __call__(self, xq, xkv, bias, mask_add, training, rng):
        h = self.ln1(ag.add(xq, ag.dropout(self.att(xq, xkv, bias, mask_add), self.p, training, rng)))
        return self.ln2(ag.add(h, ag.dropout(self.ffn(h), self.p, training, rng)))


class StructuralBias(Module):
    """Additive attention biases: time-forgetting kernel and/or concept-graph prior."""

    def __init__(self, rng, H, K, time_kind="none", graph=False):
        self.H, self.K = H, K
        self.time_kind, self.graph = time_kind, graph
        if time_kind == "time":
            self.w = Param(np.full(H, inv_softplus(0.3)) + rng.normal(0, 0.1, H))
            self.u = Param(np.zeros((K + 1, 1)))
        elif time_kind == "pos":
            self.theta = Param(np.full(H, inv_softplus(0.05)) + rng.normal(0, 0.1, H))
        if graph:
            self.G = Param(np.zeros((K + 1, K + 1)))
            self.s = Param(np.ones(H))

    def active(self):
        return self.time_kind != "none" or self.graph

    def __call__(self, kq, kk, dt_log, dpos):
        if not self.active():
            return None
        B, Lq = kq.shape
        Lk = kk.shape[1]
        H = self.H
        lin, gt = [], None
        if self.time_kind == "time":
            ue = ag.reshape(ag.embedding(self.u, kq), (B, 1, Lq, 1))
            rate = ag.softplus(ag.add(ag.reshape(self.w, (1, H, 1, 1)), ue))     # (B,H,Lq,1)
            lin.append((rate, -dt_log[:, None, :, :]))
        elif self.time_kind == "pos":
            rate = ag.softplus(ag.reshape(self.theta, (1, H, 1, 1)))
            lin.append((rate, -dpos[None, None, :, :]))
        if self.graph:
            gk = ag.reshape(ag.gather2d(self.G, kq[:, :, None], kk[:, None, :]), (B, 1, Lq, Lk))
            gt = (ag.reshape(self.s, (1, H, 1, 1)), gk)
        return lin, gt

    def forgetting_rates(self):
        """effective per-concept forgetting rate (mean over heads)."""
        if self.time_kind != "time":
            return None
        z = self.w.data[None, :] + self.u.data[:self.K, 0][:, None]
        return np.logaddexp(0, z).mean(1)


class KTTransformer(Module):
    def __init__(self, n_items, n_concepts, d=64, H=4, emb="rasch", n_enc=1, time_kind="time",
                 graph=True, ew_head=True, p_drop=0.1, max_len=121, seed=0, name="CAFE-KT", qfeat=False):
        rng = np.random.default_rng(seed)
        self.rng = np.random.default_rng(seed + 1000)
        self.name = name
        self.K, self.Q, self.d = n_concepts, n_items, d
        self.emb_kind, self.n_enc = emb, n_enc
        if emb == "item":
            self.E = Param(rng.normal(0, 0.1, (n_items, d)))
        else:
            self.C = Param(rng.normal(0, 0.1, (n_concepts, d)))
            self.Dv = Param(rng.normal(0, 0.1, (n_concepts, d)))
            self.mu = Param(np.zeros((n_items, 1)))
        self.R = Param(rng.normal(0, 0.1, (2, d)))
        self.KR = Param(rng.normal(0, 0.1, (2 * n_concepts, d)))
        self.P = Param(rng.normal(0, 0.02, (max_len + 1, d)))
        self.START = Param(rng.normal(0, 0.1, (1, 1, d)))
        self.bias = StructuralBias(rng, H, n_concepts, time_kind, graph)
        self.enc = [Block(rng, d, H, p_drop) for _ in range(n_enc)]
        self.ret = Block(rng, d, H, p_drop)
        self.out1 = Linear(rng, 2 * d, d)
        self.out2 = Linear(rng, d, 1)
        self.ew_head = ew_head
        if ew_head:
            self.ew1 = Linear(rng, d, d // 2)
            self.ew2 = Linear(rng, d // 2, 1)
        self.qfeat = qfeat
        if qfeat:
            self.Fq = Linear(rng, N_FEAT, d)
            self.Fw = Linear(rng, N_FEAT, 1, bias=False)      # wide (linear) path of the IRT-style head
            self.Fw.W.data[...] = 0
            self.bq = Param(np.zeros((n_items, 1)))             # item easiness (IRT intercept)

    def item_emb(self, q, k):
        if self.emb_kind == "item":
            return ag.embedding(self.E, q)
        return ag.add(ag.embedding(self.C, k), ag.mul(ag.embedding(self.mu, q), ag.embedding(self.Dv, k)))

    def forward(self, b, training=False, return_state=False):
        q, k, r, t = b["q"], b["k"], b["r"], b["t"]
        B, L = q.shape
        eq = self.item_emb(q, k)                                             # (B,L,d)
        pos = self.P.data.shape[0]
        P = ag.getitem(self.P, slice(0, L))
        x = ag.add(ag.add(ag.add(eq, ag.embedding(self.R, r)), ag.embedding(self.KR, k * 2 + r)), P)
        # ---------- knowledge encoder (causal, includes diagonal)
        ii = np.arange(L)
        if self.n_enc:
            dt = np.maximum(t[:, :, None] - t[:, None, :], 0)
            dt_log = np.log1p(dt).astype(np.float32)
            dpos = np.abs(ii[:, None] - ii[None, :]).astype(np.float32)
            mask = np.where(ii[None, :] <= ii[:, None], 0.0, NEG).astype(np.float32)[None, None]
            bias = self.bias(k, k, dt_log, dpos)
            h = x
            for blk in self.enc:
                h = blk(h, h, bias, mask, training, self.rng)
        else:
            h = x
        # ---------- knowledge retriever (strictly causal via START shift)
        start = ag.add(Tensor(np.zeros((B, 1, self.d), np.float32)), self.START)
        keys = ag.concat([start, ag.getitem(h, (slice(None), slice(0, L - 1)))], axis=1)
        tk = np.concatenate([t[:, :1], t[:, :-1]], axis=1)
        dt = np.maximum(t[:, :, None] - tk[:, None, :], 0)
        dt[:, :, 0] = 0
        dt_log = np.log1p(dt).astype(np.float32)
        kk = np.concatenate([np.full((B, 1), self.K), k[:, :-1]], axis=1)
        kpos = np.concatenate([[0], ii[:-1]])
        dpos = np.abs(ii[:, None] - kpos[None, :]).astype(np.float32)
        dpos[:, 0] = 0
        mask = np.where(np.arange(L)[None, :] <= ii[:, None], 0.0, NEG).astype(np.float32)[None, None]
        bias_r = self.bias(k, kk, dt_log, dpos)
        if self.qfeat:
            ft = Tensor(b["f"])
            eq = ag.add(eq, self.Fq(ft))
        qx = ag.add(eq, P)
        hr = self.ret(qx, keys, bias_r, mask, training, self.rng)
        z = ag.gelu(self.out1(ag.concat([hr, eq], axis=-1)))
        logit = ag.reshape(self.out2(z), (B, L))
        if self.qfeat:
            wide = ag.add(self.Fw(ft), ag.embedding(self.bq, q))
            logit = ag.add(logit, ag.reshape(wide, (B, L)))
        ew = None
        if self.ew_head:
            ew = ag.reshape(self.ew2(ag.gelu(self.ew1(hr))), (B, L))
        if return_state:
            return logit, ew, hr
        return logit, ew

    def predict_next(self, hist, cand_q, cand_k, t_now):
        """P(correct) for every candidate item given each student's history (used by the tutor).
        hist: dict q,k,r,t of shape (B,s); cand_q/cand_k: (C,); t_now: (B,). Returns (B,C)."""
        with ag.no_grad():
            B, s = hist["q"].shape
            C = len(cand_q)
            start = ag.add(Tensor(np.zeros((B, 1, self.d), np.float32)), self.START)
            if s > 0:
                q, k, r, t = hist["q"], hist["k"], hist["r"], hist["t"]
                eqh = self.item_emb(q, k)
                P = ag.getitem(self.P, slice(0, s))
                x = ag.add(ag.add(ag.add(eqh, ag.embedding(self.R, r)), ag.embedding(self.KR, k * 2 + r)), P)
                ii = np.arange(s)
                if self.n_enc:
                    dt = np.maximum(t[:, :, None] - t[:, None, :], 0)
                    dt_log = np.log1p(dt).astype(np.float32)
                    dpos = np.abs(ii[:, None] - ii[None, :]).astype(np.float32)
                    mask = np.where(ii[None, :] <= ii[:, None], 0.0, NEG).astype(np.float32)[None, None]
                    bias = self.bias(k, k, dt_log, dpos)
                    h = x
                    for blk in self.enc:
                        h = blk(h, h, bias, mask, False, self.rng)
                else:
                    h = x
                keys = ag.concat([start, h], axis=1)
                tk = np.concatenate([t_now[:, None], t], axis=1)
                kk = np.concatenate([np.full((B, 1), self.K), k], axis=1)
                kpos = np.concatenate([[s], ii])
            else:
                keys = start
                tk = t_now[:, None]
                kk = np.full((B, 1), self.K)
                kpos = np.array([s])
            dt = np.maximum(t_now[:, None] - tk, 0)
            dt[:, 0] = 0
            dt_log = np.broadcast_to(np.log1p(dt)[:, None, :], (B, C, s + 1)).astype(np.float32)
            dpos = np.broadcast_to(np.abs(s - kpos).astype(np.float32)[None, :], (C, s + 1))
            mask = np.zeros((1, 1, C, s + 1), np.float32)
            cq = np.broadcast_to(cand_q[None, :], (B, C))
            ck = np.broadcast_to(cand_k[None, :], (B, C))
            eq = self.item_emb(cq, ck)
            if self.qfeat:
                fe = Tensor(candidate_features(hist["q"], hist["k"], hist["r"], hist["t"], cand_k, t_now, self.K))
                eq = ag.add(eq, self.Fq(fe))
            qx = ag.add(eq, ag.getitem(self.P, slice(s, s + 1)))
            bias_r = self.bias(ck, kk, dt_log, dpos)
            hr = self.ret(qx, keys, bias_r, mask, False, self.rng)
            z = ag.gelu(self.out1(ag.concat([hr, eq], axis=-1)))
            logit = ag.reshape(self.out2(z), (B, C))
            if self.qfeat:
                wide = ag.add(self.Fw(fe), ag.embedding(self.bq, cq))
                logit = ag.add(logit, ag.reshape(wide, (B, C)))
            return ag._sig(logit.data)

    def reg_loss(self):
        if self.bias.graph:
            return ag.mean(ag.absval(self.bias.G))
        return None

    # graph read-out (child, parent) = G[k_query, k_key]
    def concept_graph(self):
        if not self.bias.graph:
            return None
        return (self.bias.G.data[:self.K, :self.K] * self.bias.s.data.mean())


# ------------------------------------------------------------------ DKT (fused LSTM)
def lstm_op(XW, Wh):
    """Fused LSTM over time. XW: (B,L,4h) Tensor (input projection incl. bias); Wh: (h,4h) Param."""
    X = XW.data
    W = Wh.data
    B, L, H4 = X.shape
    Hd = H4 // 4
    hs = np.zeros((B, L, Hd), X.dtype)
    cache = []
    h = np.zeros((B, Hd), X.dtype)
    c = np.zeros((B, Hd), X.dtype)
    sg = ag._sig
    for t in range(L):
        z = X[:, t] + h @ W
        i = sg(z[:, :Hd]); f = sg(z[:, Hd:2 * Hd]); g = np.tanh(z[:, 2 * Hd:3 * Hd]); o = sg(z[:, 3 * Hd:])
        c_new = f * c + i * g
        tc = np.tanh(c_new)
        h_new = o * tc
        cache.append((i, f, g, o, c, tc, h))
        h, c = h_new, c_new
        hs[:, t] = h
    out = Tensor(hs, (XW, Wh))

    def back(gH):
        dX = np.zeros_like(X)
        dW = np.zeros_like(W)
        dh_next = np.zeros((B, Hd), X.dtype)
        dc_next = np.zeros((B, Hd), X.dtype)
        for t in reversed(range(L)):
            i, f, g, o, c_prev, tc, h_prev = cache[t]
            dh = gH[:, t] + dh_next
            do = dh * tc
            dc = dc_next + dh * o * (1 - tc * tc)
            di = dc * g
            dg = dc * i
            df = dc * c_prev
            dc_next = dc * f
            dz = np.concatenate([di * i * (1 - i), df * f * (1 - f), dg * (1 - g * g), do * o * (1 - o)], axis=1)
            dX[:, t] = dz
            dW += h_prev.T @ dz
            dh_next = dz @ W.T
        ag._acc(XW, dX)
        ag._acc(Wh, dW)
    out._back = back if out._parents else None
    return out


class DKT(Module):
    def __init__(self, n_items, n_concepts, d=64, ew_head=True, seed=0, name="DKT", **kw):
        rng = np.random.default_rng(seed)
        self.name = name
        self.K = n_concepts
        self.X = Param(rng.normal(0, 0.1, (2 * n_concepts, d)))
        self.Wx = Linear(rng, d, 4 * d)
        self.Wh = Param(ag.xavier(rng, d, 4 * d))
        self.out = Linear(rng, d, n_concepts)
        self.h0 = Param(np.zeros((1, 1, d)))
        self.d = d
        self.ew_head = ew_head
        if ew_head:
            self.ew1 = Linear(rng, d, d // 2)
            self.ew2 = Linear(rng, d // 2, 1)
        self.Wx.b.data[d:2 * d] = 1.0   # forget-gate bias

    def forward(self, b, training=False, return_state=False):
        k, r = b["k"], b["r"]
        B, L = k.shape
        x = ag.embedding(self.X, k * 2 + r)
        hs = lstm_op(self.Wx(x), self.Wh)
        h0 = ag.add(Tensor(np.zeros((B, 1, self.d), np.float32)), self.h0)
        hsh = ag.concat([h0, ag.getitem(hs, (slice(None), slice(0, L - 1)))], axis=1)  # state before step i
        lo = self.out(hsh)                                                       # (B,L,K)
        oh = np.zeros((B, L, self.K), np.float32)
        np.put_along_axis(oh, k[:, :, None], 1.0, axis=2)
        logit = ag.tsum(ag.mul(lo, Tensor(oh)), axis=-1)
        ew = None
        if self.ew_head:
            ew = ag.reshape(self.ew2(ag.gelu(self.ew1(hsh))), (B, L))
        if return_state:
            return logit, ew, hsh
        return logit, ew

    def predict_next(self, hist, cand_q, cand_k, t_now):
        with ag.no_grad():
            B, s = hist["k"].shape
            if s == 0:
                h = np.broadcast_to(self.h0.data[:, 0], (B, self.d))
            else:
                x = ag.embedding(self.X, hist["k"] * 2 + hist["r"])
                h = lstm_op(self.Wx(x), self.Wh).data[:, -1]
            lo = h @ self.out.W.data + self.out.b.data
            return ag._sig(lo[:, cand_k])

    def reg_loss(self):
        return None


def make_model(name, n_items, n_concepts, seed, **over):
    cfgs = {
        "SAKT": dict(emb="item", n_enc=0, time_kind="none", graph=False, ew_head=True),
        "AKT-s": dict(emb="rasch", n_enc=1, time_kind="pos", graph=False, ew_head=True),
        "CAFE-KT": dict(emb="rasch", n_enc=1, time_kind="time", graph=True, ew_head=True, qfeat=True),
        "CAFE-KT w/o query features": dict(emb="rasch", n_enc=1, time_kind="time", graph=True, ew_head=True,
                                          qfeat=False),
        # ablations
        "CAFE-KT w/o forgetting kernel": dict(emb="rasch", n_enc=1, time_kind="none", graph=True, ew_head=True, qfeat=True),
        "CAFE-KT w/ position decay": dict(emb="rasch", n_enc=1, time_kind="pos", graph=True, ew_head=True, qfeat=True),
        "CAFE-KT w/o concept graph": dict(emb="rasch", n_enc=1, time_kind="time", graph=False, ew_head=True, qfeat=True),
        "CAFE-KT w/o Rasch emb.": dict(emb="item", n_enc=1, time_kind="time", graph=True, ew_head=True, qfeat=True),
        "CAFE-KT w/o early-warning head": dict(emb="rasch", n_enc=1, time_kind="time", graph=True, ew_head=False, qfeat=True),
    }
    if name == "DKT":
        return DKT(n_items, n_concepts, seed=seed, **over)
    base = name if name in cfgs else "CAFE-KT"
    cfg = dict(cfgs[base])
    cfg.update(over)
    return KTTransformer(n_items, n_concepts, seed=seed, name=name, **cfg)

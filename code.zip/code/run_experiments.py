"""
Experiment runner for the CAFE-KT study.

    python run_experiments.py --list                 # show all jobs
    python run_experiments.py --worker 0 --n_workers 2   # run a share of the jobs
Every job writes  results/runs/<job_id>.json  (+ predictions .npz, + model .pkl for transformers),
so the study can be resumed and every number in the paper is traceable to a file.
"""
import argparse
import json
import os
import pickle
import time

import numpy as np

import data as dmod
import models
import train
import classic
from metrics import kt_metrics, group_metrics, abroca, ew_metrics, best_f1_threshold

ROOT = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(ROOT, "..", "data", "raw")
OUT = os.path.join(ROOT, "..", "results", "runs")
EW_T = [10, 20, 40]

# objective used by CAFE-KT (selected on the validation split, see stage "equity")
CAFE_OBJ = dict(balanced=True, lambda_eq=10.0, lambda_ew=0.3, lambda_G=1e-3)
BASE_OBJ = dict(balanced=False, lambda_eq=0.0, lambda_ew=0.3, lambda_G=1e-3)
NEURAL = ["DKT", "SAKT", "AKT-s", "CAFE-KT"]
CLASSIC = ["BKT", "PFA", "GBDT-FE"]


def jobs():
    J = []
    for s in range(5):
        for m in CLASSIC + ["EW-LR", "EW-GBDT"]:
            J.append(dict(stage="main", model=m, seed=s, cost=1))
        for m in NEURAL:
            J.append(dict(stage="main", model=m, seed=s, obj=CAFE_OBJ if m == "CAFE-KT" else BASE_OBJ,
                          cost={"DKT": 2, "SAKT": 4, "AKT-s": 8, "CAFE-KT": 8}[m]))
    abl = ["CAFE-KT w/o forgetting kernel", "CAFE-KT w/ position decay", "CAFE-KT w/o concept graph",
           "CAFE-KT w/o Rasch emb.", "CAFE-KT w/o early-warning head", "CAFE-KT w/o query features"]
    for s in range(3):
        for m in abl:
            J.append(dict(stage="ablation", model=m, seed=s, obj=CAFE_OBJ, cost=8))
        J.append(dict(stage="ablation", model="CAFE-KT w/o equity objective", arch="CAFE-KT", seed=s,
                      obj=BASE_OBJ, cost=8))
    for s in [3, 4]:       # accuracy-oriented CAFE-KT on the remaining seeds (for the five-seed comparison)
        J.append(dict(stage="accmode", model="CAFE-KT w/o equity objective", arch="CAFE-KT", seed=s,
                      obj=BASE_OBJ, cost=8))
    for s in range(2):
        for lam in [0.0, 2.0, 50.0]:
            J.append(dict(stage="equity", model=f"CAFE-KT lambda_eq={lam:g}", arch="CAFE-KT", seed=s,
                          obj=dict(CAFE_OBJ, lambda_eq=lam), cost=8))
    for s in range(2):
        for frac in [0.1, 0.25, 0.5]:
            for m in ["GBDT-FE", "SAKT", "AKT-s", "CAFE-KT"]:
                J.append(dict(stage="sparsity", model=m, seed=s, frac=frac,
                              obj=CAFE_OBJ if m == "CAFE-KT" else BASE_OBJ,
                              cost=max(1, int(8 * frac)) if m != "GBDT-FE" else 1))
    for j in J:
        sfx = f"__f{j['frac']}" if "frac" in j else ""
        stg = "ablation" if j["stage"] == "accmode" else j["stage"]
        j["id"] = f"{stg}__{j['model'].replace(' ', '_').replace('/', '')}__s{j['seed']}{sfx}"
    return J


def eval_kt(Dsplit, P):
    y, p, g = train.flat(Dsplit, P)
    out = kt_metrics(y, p)
    gm = group_metrics(y, p, g)
    out["group"] = {str(k): v for k, v in gm.items()}
    out["ABROCA"] = abroca(y, p, g)
    return out


def eval_ew(D, E_val, E_test):
    res = {}
    for t in EW_T:
        iv = np.where(D["val"].length > t)[0]
        it = np.where(D["test"].length > t)[0]
        thr = best_f1_threshold(D["val"].dropout[iv].astype(int), E_val[iv, t])
        res[str(t)] = ew_metrics(D["test"].dropout[it].astype(int), E_test[it, t], D["test"].group[it], thr)
    return res


def run_job(j):
    path = os.path.join(OUT, j["id"] + ".json")
    if os.path.exists(path):
        return
    t0 = time.time()
    D, Q, K, inter, stud, sp = dmod.build(RAW, seed=j["seed"], train_frac=j.get("frac", 1.0))
    rec = dict(job=j, n_train_students=int(D["train"].n))
    m = j["model"]
    preds = {}
    if m in ("EW-LR", "EW-GBDT"):
        res = {}
        for t in EW_T:
            mdl = classic.EWBaseline(m.split("-")[1], seed=j["seed"]).fit(D["train"], t)
            iv, pv = mdl.predict(D["val"], t)
            thr = best_f1_threshold(D["val"].dropout[iv].astype(int), pv)
            it, pt = mdl.predict(D["test"], t)
            res[str(t)] = ew_metrics(D["test"].dropout[it].astype(int), pt, D["test"].group[it], thr)
        rec["ew"] = res
    elif m in CLASSIC:
        if m == "BKT":
            mdl = classic.BKT(K).fit(D["train"])
        elif m == "PFA":
            mdl = classic.PFA(Q, K).fit(D["train"])
        else:
            mdl = classic.GBDTKT(Q, seed=j["seed"]).fit(D["train"])
        rec["train_sec"] = time.time() - t0
        for sp_ in ["val", "calib", "test"]:
            preds["P_" + sp_] = mdl.predict(D[sp_])
        ti = time.time()
        mdl.predict(D["test"])
        rec["infer_sec_test"] = time.time() - ti
        rec["kt"] = eval_kt(D["test"], preds["P_test"])
        rec["kt_val"] = eval_kt(D["val"], preds["P_val"])
    else:
        arch = j.get("arch", m)
        mdl = models.make_model(arch, Q, K, seed=j["seed"])
        mdl.name = m
        info = train.fit(mdl, D, dict(j.get("obj", {}), verbose=False), seed=j["seed"])
        rec["train"] = {k: v for k, v in info.items()}
        rec["n_params"] = mdl.n_params()
        for sp_ in ["val", "calib", "test"]:
            P, E = train.predict(mdl, D[sp_])
            preds["P_" + sp_] = P
            preds["E_" + sp_] = E
        ti = time.time()
        train.predict(mdl, D["test"])
        rec["infer_sec_test"] = time.time() - ti
        rec["n_test_predictions"] = int(D["test"].m.sum())
        rec["kt"] = eval_kt(D["test"], preds["P_test"])
        rec["kt_val"] = eval_kt(D["val"], preds["P_val"])
        if getattr(mdl, "ew_head", False):
            rec["ew"] = eval_ew(D, preds["E_val"], preds["E_test"])
        if hasattr(mdl, "bias"):
            if mdl.bias.graph:
                rec["G"] = mdl.concept_graph().tolist()
            fr = mdl.bias.forgetting_rates()
            if fr is not None:
                rec["forgetting_rates"] = fr.tolist()
        with open(os.path.join(OUT, j["id"] + ".pkl"), "wb") as f:
            pickle.dump(mdl.state_dict(), f)
    if preds:
        np.savez_compressed(os.path.join(OUT, j["id"] + ".npz"), **preds)
    rec["wall_sec"] = time.time() - t0
    with open(path, "w") as f:
        json.dump(rec, f, indent=1)
    kt = rec.get("kt", {})
    print(f"[done] {j['id']}  AUC={kt.get('AUC', float('nan')):.4f}  ({rec['wall_sec']:.0f}s)", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--n_workers", type=int, default=1)
    ap.add_argument("--stage", default=None)
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--models", default=None, help="comma-separated model filter")
    ap.add_argument("--exclude", default=None, help="comma-separated models to skip")
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    J = jobs()
    if a.stage:
        J = [j for j in J if j["stage"] in a.stage.split(",")]
    if a.models:
        J = [j for j in J if j["model"] in a.models.split(",")]
    if a.exclude:
        J = [j for j in J if j["model"] not in a.exclude.split(",")]
    if a.list:
        for j in J:
            print(j["id"], j.get("cost"))
        print(len(J), "jobs; total cost", sum(j.get("cost", 1) for j in J))
        return
    # greedy balanced assignment by cost (within stage order)
    loads = [0] * a.n_workers
    mine = []
    for j in J:
        w = int(np.argmin(loads))
        loads[w] += j.get("cost", 1)
        if w == a.worker:
            mine.append(j)
    for j in mine:
        try:
            run_job(j)
        except Exception as e:  # keep going; failures are logged
            import traceback
            print(f"[FAIL] {j['id']}: {e}", flush=True)
            traceback.print_exc()


if __name__ == "__main__":
    main()
